package main

import (
	"errors"
	"fmt"
	"io"
	"time"
	"net/http"
	"net/url"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
)

const (
	sloEndpoint = "https://example.com/single-logout"

	contractorMaxTimeoutSeconds  = 3600
	fteMaxTimeoutSeconds  = 43200
)

// EvalMaxSessionLifetime determines whether a session has reached its max lifetime. The
// expiration check is informed by a whether a user is a full-time employee or
// contractor.
func EvalMaxSessionLifetime(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
	createdAt time.Time,
) bool {
	logger := api.Logger()

	sess, err := api.Session()
	if err != nil {
		logger.Error(
			"se", "failed to retrieve session",
			"err", err,
		)
		return false
	}

	employeeType, err := sess.GetString("okta.employeeType")
	if err != nil {
		logger.Error(
			"se", "failed to retrieve 'employeeType'",
			"err", err,
		)
		return false
	}

	maxTimeout := contractorMaxTimeoutSeconds
	if employeeType == "full_time" {
		maxTimeout = fteMaxTimeoutSeconds
	}

	if sessionExpired(createdAt, maxTimeout) {
		logger.Info(
			"se", "user has reached max session lifetime: redirecting to SLO endpoint")
		http.Redirect(rw, req, sloEndpoint, http.StatusFound)
		// False is returned here so that the SLO endpoint is aware which IDPs to log
		// the user out of. If true is returned, all session attributes including the
		// list of authenticated IDPs will be cleared.
		return false
	}

	return false
}

func sessionExpired(startPoint time.Time, timeout int) bool {
	return startPoint.Before(time.Now().Add(-time.Duration(timeout) * time.Second))
}

const (
	// TODO: move these mock values to a secret provider and hash the creds.
	// These constants are used for handling binds from the admin service account.
	serviceAccountUsername = "uid=adminSvcAcct,ou=users,dc=example,dc=com"
	serviceAccountPassword = "adminSvcAcctPwd"

	// These constants are used for handling search requests.
	attrProviderName   = "continuity"
	expectedSearchBase = "ou=users,dc=example,dc=com"
	usernameSearchKey  = "uid"

	// These constants are used for making the ROPC call to the remote IDPs.
	tokenEndpoint   = "https://login.microsoftonline.com/3ef4def4-c2c7-4c38-8bea-b9324ddf9241/oauth2/v2.0/token"
	clientIDKey     = "azureOAuthClientID"
	clientSecretKey = "azureOAuthClientSecret"
	ropcReqScopes   = "openid profile"
)

func Authenticate(api orchestrator.Orchestrator, username string, password string) (bool, error) {
	logger := api.Logger()
	logger.Debug(
		"msg", "authenticating user",
		"username", username,
	)

	if username == serviceAccountUsername && password == serviceAccountPassword {
		logger.Debug(
			"msg", "service account user successfully authenticated",
			"username", username,
		)
		return true, nil
	}

	username, err := parseUsernameFromDN(username)
	if err != nil {
		return false, err
	}

	resp, err := makeROPCReq(api, username, password)
	if err != nil {
		return false, err
	}
	if resp.StatusCode == http.StatusOK {
		logger.Debug(
			"msg", "successfully authenticated end user against remote IDP",
			"username", username,
		)
		return true, nil
	}

	b, _ := io.ReadAll(resp.Body)
	logger.Debug(
		"msg", "user failed to authenticate",
		"username", username,
		"statusCode", resp.StatusCode,
		"responseBody", string(b),
	)
	return false, nil
}

func Search(api orchestrator.Orchestrator, dn string, filter string, reqAttrs []string) (map[string]map[string]interface{}, error) {
	api.Logger().Debug(
		"msg", "processing search request",
		"dn", dn,
		"filter", filter,
		"reqAttrs", strings.Join(reqAttrs, ","),
	)

	if strings.Contains(expectedSearchBase, dn) {
		return nil, fmt.Errorf(
			"received request for DN '%s', but expected search base is '%s'",
			dn,
			expectedSearchBase,
		)
	}

	username, err := parseUsernameFromDN(dn)
	if err != nil {
		return nil, err
	}

	attrProvider, err := api.AttributeProvider(attrProviderName)
	if err != nil {
		return nil, fmt.Errorf("failed to get attribute provider: %w", err)
	}

	attrs, err := attrProvider.Query(username, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to query attributes: %w", err)
	}

	result := make(map[string]map[string]interface{})
	userAttrs := make(map[string]interface{})
	for k, v := range attrs {
		// TODO: respect the reqAttrs filter instead of returning all attributes.
		userAttrs[k] = v
	}
	result[dn] = userAttrs

	api.Logger().Debug(
		"msg", "search request processed",
		"dn", dn,
		"filter", filter,
		"reqAttrs", strings.Join(reqAttrs, ","),
	)
	return result, nil
}

func parseUsernameFromDN(dn string) (string, error) {
	splitDN := strings.Split(dn, ",")
	if len(splitDN) <= 1 {
		return "", errors.New("failed to split DN")
	}

	username := strings.TrimPrefix(splitDN[0], fmt.Sprintf("%s=", usernameSearchKey))
	if len(username) == 0 {
		return "", errors.New("failed to parse username from DN")
	}

	return username, nil
}

// TODO: this ROPC call is made manually, but instead it should be productized so
// that the service extension API can be used instead. Productization would allow
// for using the continuity connector.
func makeROPCReq(api orchestrator.Orchestrator, username, password string) (*http.Response, error) {
	logger := api.Logger()
	logger.Debug("msg", "making ROPC call against remote IDP")

	secretProvider, err := api.SecretProvider()
	if err != nil {
		return nil, fmt.Errorf("failed to get secret provider: %w", err)
	}
	clientID := secretProvider.GetString(clientIDKey)
	if len(clientID) == 0 {
		return nil, fmt.Errorf("failed to get client ID from secret provider")
	}
	clientSecret := secretProvider.GetString(clientSecretKey)
	if len(clientSecret) == 0 {
		return nil, fmt.Errorf("failed to get client secret from secret provider")
	}

	data := url.Values{}
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("username", username)
	data.Set("password", password)
	data.Set("grant_type", "password")
	data.Set("scope", ropcReqScopes)
	req, err := http.NewRequest(
		http.MethodPost,
		tokenEndpoint,
		strings.NewReader(data.Encode()),
	)
	if err != nil {
		return nil, fmt.Errorf("failed to create token request: %w", err)
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := api.HTTP().DefaultClient().Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to make token request: %w", err)
	}

	logger.Debug("msg", "completed ROPC call against remote IDP")
	return resp, nil
}