package main

import (
	"errors"
	"fmt"
	"io"
	"time"
	"net/http"
	"net/url"
	"strings"
    "crypto/tls"
	"github.com/strata-io/service-extension/orchestrator"
)
const (
	// TODO: move these mock values to a secret provider and hash the creds.
	// These constants are used for handling binds from the admin service account.
	serviceAccountUsername = "cn=adminSvcAcct,ou=users,dc=example,dc=com"
	serviceAccountPassword = "adminSvcAcctPwd"

	// These constants are used for handling search requests.
	attrProviderName   = "Entra_Maverics9_Graph"
	expectedSearchBase = "ou=users,dc=example,dc=com"
	usernameSearchKey  = "cn"

	// These constants are used for making the ROPC call to the remote IDPs.
	entraURL    = "https://login.microsoftonline.com/2eeef3fb-4a94-4a6b-a18f-22f53553f182/v2.0/.well-known/openid-configuration"
	tokenEndpoint   = "https://login.microsoftonline.com/2eeef3fb-4a94-4a6b-a18f-22f53553f182/oauth2/v2.0/token"
	clientIDKey     = "azureOAuthClientID"
	clientSecretKey = "azureOAuthClientSecret"
	ropcReqScopes   = "openid"
	
	// It's dangerous to go alone. Bring a friend
	kcTokenEndpoint   = "https://keycloak.strata-eval.io/realms/maverics/protocol/openid-connect/token"
	kcClientIDKey     = "kcOAuthClientID"
	kcClientSecretKey = "kcOAuthClientSecret"
	kcRopcReqScopes   = "openid"
)

func Authenticate(api orchestrator.Orchestrator, username string, password string) (bool, error) {
	logger := api.Logger()
	logger.Debug(
		"msg", "authenticating user",
		"username", username,
	)

	if username == serviceAccountUsername && password == serviceAccountPassword {
		logger.Debug(
			"msg", "service account user successfully authenticated",
			"username", username,
		)
		return true, nil
	}

	username, err := parseUsernameFromDN(username)
	if err != nil {
		return false, err
	}

	resp, err := makeROPCReq(api, username, password)
	if err != nil {
		return false, err
	}
	if resp.StatusCode == http.StatusOK {
		logger.Debug(
			"msg", "successfully authenticated end user against remote IDP",
			"username", username,
		)
		return true, nil
	}

	b, _ := io.ReadAll(resp.Body)
	logger.Debug(
		"msg", "user failed to authenticate",
		"username", username,
		"statusCode", resp.StatusCode,
		"responseBody", string(b),
	)
	return false, nil
}

/*func Search(api orchestrator.Orchestrator, dn string, filter string, reqAttrs []string) (map[string]map[string]interface{}, error) {
	api.Logger().Debug(
		"msg", "INCOMING SEARCH REQUEST!",
		"Search Base DN", dn,
		"LDAP Filter", filter,
		"Requested Attributes", strings.Join(reqAttrs, ","),
	)

	if strings.Contains(expectedSearchBase, dn) {
		return nil, fmt.Errorf(
			"received request for DN '%s', but expected search base is '%s'",
			dn,
			expectedSearchBase,
		)
	}

	username, err := parseUsernameFromDN(dn)
	if err != nil {
		return nil, err
	}

	attrProvider, err := api.AttributeProvider(attrProviderName)
	if err != nil {
		return nil, fmt.Errorf("failed to get attribute provider: %w", err)
	}

	attrs, err := attrProvider.Query(username, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to query attributes: %w", err)
	}

	result := make(map[string]map[string]interface{})
	userAttrs := make(map[string]interface{})
	for k, v := range attrs {
		// TODO: respect the reqAttrs filter instead of returning all attributes.
		userAttrs[k] = v
	}
	result[dn] = userAttrs

	api.Logger().Debug(
		"msg", "search request processed",
		"dn", dn,
		"filter", filter,
		"reqAttrs", strings.Join(reqAttrs, ","),
	)
	return result, nil
}*/
func Search(api orchestrator.Orchestrator, dn string, filter string, reqAttrs []string) (map[string]map[string]interface{}, error) {
	api.Logger().Debug(
		"msg", "INCOMING SEARCH REQUEST!",
		"Search Base DN", dn,
		"LDAP Filter", filter,
		"Requested Attributes", strings.Join(reqAttrs, ","),
	)

	if strings.Contains(expectedSearchBase, dn) {
		return nil, fmt.Errorf(
			"received request for DN '%s', but expected search base is '%s'",
			dn,
			expectedSearchBase,
		)
	}

	username, err := parseUsernameFromDN(dn)
	if err != nil {
		return nil, err
	}
api.Logger().Debug("ldap-search","Getting Directory Info")
	attrProvider, err := api.AttributeProvider(attrProviderName)
	if err != nil {
		return nil, fmt.Errorf("failed to get attribute provider: %w", err)
	}

	// Ask explicitly for memberOf groups
	attrs, err := attrProvider.Query(username, []string{"memberOf"})
	if err != nil {
		return nil, fmt.Errorf("failed to query attributes: %w", err)
	}

	memberOfStr, ok := attrs["memberOf"]
	api.Logger().Debug("ldap-search","Groups retrieved: "+memberOfStr)
	if !ok {
		return nil, fmt.Errorf("no 'memberOf' attribute found for user")
	}

	// Split and trim group names
	groupNames := strings.Split(memberOfStr, ",")
	for i := range groupNames {
		groupNames[i] = strings.TrimSpace(groupNames[i])
	}
api.Logger().Debug("ldap-search","Filtering on: "+filter)
	// Filter group names using the 'filter' value (case-insensitive)
	var memberOf []string
	for _, group := range groupNames {
		if strings.Contains(strings.ToLower(group), strings.ToLower(filter)) {
			memberOf = append(memberOf, group)
		}
	}

	result := map[string]map[string]interface{}{
		dn: {
			"memberOf": memberOf,
		},
	}

	api.Logger().Debug(
		"msg", "search request processed",
		"dn", dn,
		"filter", filter,
		"memberOf", strings.Join(memberOf, ","),
	)
	return result, nil
}

func parseUsernameFromDN(dn string) (string, error) {
	splitDN := strings.Split(dn, ",")
	if len(splitDN) <= 1 {
		return "", errors.New("failed to split DN")
	}

	username := strings.TrimPrefix(splitDN[0], fmt.Sprintf("%s=", usernameSearchKey))
	if len(username) == 0 {
		return "", errors.New("failed to parse username from DN")
	}

	return username, nil
}

// TODO: this ROPC call is made manually, but instead it should be productized so
// that the service extension API can be used instead. Productization would allow
// for using the continuity connector.
func makeROPCReq(api orchestrator.Orchestrator, username, password string) (*http.Response, error) {
	logger := api.Logger()
	httpClient := api.HTTP().DefaultClient()

	// Check Entra ID well-known endpoint
	logger.Debug("msg", "checking Entra ID connectivity")
	entraOK := false
	entraReq, _ := http.NewRequest(http.MethodGet, entraURL, nil)
	entraReq.Header.Set("Accept", "application/json")

	client := *httpClient
	client.Timeout = 3 * time.Second
	entraResp, err := client.Do(entraReq)
	if err == nil && entraResp.StatusCode >= 200 && entraResp.StatusCode < 300 {
		entraOK = true
		logger.Debug("msg", "entra ID connectivity check succeeded")
	} else {
		logger.Debug("msg", "entra ID connectivity check failed", "error", fmt.Sprintf("%v", err))
	}

	// Check localhost health endpoint
// Check localhost health endpoint
logger.Debug("msg", "checking local health endpoint")
localOK := false
localURL := "https://localhost/get"
localReq, _ := http.NewRequest(http.MethodGet, localURL, nil)
localReq.Header.Set("Accept", "text/plain")

// Skip TLS verification for localhost only
insecureTLSClient := &http.Client{
	Timeout: 3 * time.Second,
	Transport: &http.Transport{
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,
		},
	},
}

localResp, err := insecureTLSClient.Do(localReq)
if err == nil && localResp.StatusCode == 200 {
	bodyBytes, _ := io.ReadAll(localResp.Body)
	if strings.TrimSpace(string(bodyBytes)) == "Up" {
		localOK = true
		logger.Debug("msg", "local health check succeeded")
	} else {
		logger.Debug("msg", "local health check failed: body was not 'Up'")
	}
} else {
	logger.Debug("msg", "local health check failed", "error", fmt.Sprintf("%v", err))
}

	// Determine IDP target
	useKeycloak := !(entraOK && localOK)
	logger.Debug("msg", "IDP target decision", "useKeycloak", useKeycloak)

	// Retrieve appropriate credentials and endpoint
	secretProvider, err := api.SecretProvider()
	if err != nil {
		return nil, fmt.Errorf("failed to get secret provider: %w", err)
	}

	var clientID, clientSecret, endpoint, scope string
	if useKeycloak {
		clientID = secretProvider.GetString(kcClientIDKey)
		clientSecret = secretProvider.GetString(kcClientSecretKey)
		endpoint = kcTokenEndpoint
		scope = kcRopcReqScopes
	} else {
		clientID = secretProvider.GetString(clientIDKey)
		clientSecret = secretProvider.GetString(clientSecretKey)
		endpoint = tokenEndpoint
		scope = ropcReqScopes
	}

	if clientID == "" || clientSecret == "" {
		return nil, fmt.Errorf("missing client credentials for selected IDP")
	}

	// Construct ROPC token request
	data := url.Values{}
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("username", username)
	data.Set("password", password)
	data.Set("grant_type", "password")
	data.Set("scope", scope)

	req, err := http.NewRequest(http.MethodPost, endpoint, strings.NewReader(data.Encode()))
	if err != nil {
		return nil, fmt.Errorf("failed to create token request: %w", err)
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	logger.Debug("msg", "making ROPC call", "endpoint", endpoint)
	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to make token request: %w", err)
	}

	logger.Debug("msg", "completed ROPC call", "endpoint", endpoint)
	return resp, nil
}