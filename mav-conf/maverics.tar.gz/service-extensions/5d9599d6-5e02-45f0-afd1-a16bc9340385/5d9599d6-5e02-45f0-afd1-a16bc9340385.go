package main

import (
	"errors"
	"fmt"
	"strings"
	"github.com/strata-io/service-extension/orchestrator"
	"github.com/strata-io/service-extension/idfabric"
)
const (
	// TODO: move these mock values to a secret provider and hash the creds.
	// These constants are used for handling binds from the admin service account.
	serviceAccountUsername = "cn=adminSvcAcct,ou=users,dc=example,dc=com"
	serviceAccountPassword = "adminSvcAcctPwd"
	usernameSearchKey  = "cn"
)

func Authenticate(api orchestrator.Orchestrator, username string, password string) (bool, error) {
	logger := api.Logger()
	logger.Debug(
		"msg", "authenticating user",
		"username", username,
	)

	if username == serviceAccountUsername && password == serviceAccountPassword {
		logger.Debug(
			"msg", "service account user successfully authenticated",
			"username", username,
		)
		return true, nil
	}

	username, err := parseUsernameFromDN(username)
	if err != nil {
		return false, err
	}
	idp,err := api.IdentityProvider("Entra_Keycloak_DDIL_v3")
	if(err != nil){
	    logger.Error("ldap-auth","Couldn't load the continuity strategy for authN 'Entra_Keycloak_DDIL_v3': ","error", err)
	    return false, err
	}
    var loginResult idfabric.LoginResult
    idp.Login(nil, nil, idfabric.WithGrantTypeROPC(
    idfabric.ROPCRequest{Username: username, Password: password},
    &loginResult,
    ))
    if loginResult.Error != nil {
        logger.Error("se", "failed to login user", "error", loginResult.Error)
        return false, loginResult.Error
    }
    return true, nil
}


func parseUsernameFromDN(dn string) (string, error) {
	splitDN := strings.Split(dn, ",")
	if len(splitDN) <= 1 {
		return "", errors.New("failed to split DN")
	}

	username := strings.TrimPrefix(splitDN[0], fmt.Sprintf("%s=", usernameSearchKey))
	if len(username) == 0 {
		return "", errors.New("failed to parse username from DN")
	}

	return username, nil
}

