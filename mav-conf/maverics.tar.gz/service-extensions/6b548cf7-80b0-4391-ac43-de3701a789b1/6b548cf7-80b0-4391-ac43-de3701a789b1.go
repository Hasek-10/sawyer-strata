package main
import (
    "strings"
    "fmt"
    "errors"
	"github.com/strata-io/service-extension/orchestrator"
)
const (
	// TODO: move these mock values to a secret provider and hash the creds.
	// These constants are used for handling binds from the admin service account.
	serviceAccountUsername = "cn=adminSvcAcct,ou=users,dc=example,dc=com"
	serviceAccountPassword = "adminSvcAcctPwd"

	// These constants are used for handling search requests.
	attrProviderName   = "Entra_Maverics9_Graph"
	expectedSearchBase = "ou=users,dc=example,dc=com"
	usernameSearchKey  = "cn"

	// These constants are used for making the ROPC call to the remote IDPs.
	entraURL    = "https://login.microsoftonline.com/2eeef3fb-4a94-4a6b-a18f-22f53553f182/v2.0/.well-known/openid-configuration"
	tokenEndpoint   = "https://login.microsoftonline.com/2eeef3fb-4a94-4a6b-a18f-22f53553f182/oauth2/v2.0/token"
	clientIDKey     = "azureOAuthClientID"
	clientSecretKey = "azureOAuthClientSecret"
	ropcReqScopes   = "openid"
	
	// It's dangerous to go alone. Bring a friend
	kcTokenEndpoint   = "https://keycloak.strata-eval.io/realms/maverics/protocol/openid-connect/token"
	kcClientIDKey     = "kcOAuthClientID"
	kcClientSecretKey = "kcOAuthClientSecret"
	kcRopcReqScopes   = "openid"
)
func Search(api orchestrator.Orchestrator, dn string, filter string, reqAttrs []string) (map[string]map[string]interface{}, error) {
	api.Logger().Debug(
		"msg", "INCOMING SEARCH REQUEST!",
		"Search Base DN", dn,
		"LDAP Filter", filter,
		"Requested Attributes", strings.Join(reqAttrs, ","),
	)

	if strings.Contains(expectedSearchBase, dn) {
		return nil, fmt.Errorf(
			"received request for DN '%s', but expected search base is '%s'",
			dn,
			expectedSearchBase,
		)
	}

	username, err := parseUsernameFromDN(dn)
	if err != nil {
		return nil, err
	}
api.Logger().Debug("ldap-search","Getting Directory Info")
	attrProvider, err := api.AttributeProvider(attrProviderName)
	if err != nil {
		return nil, fmt.Errorf("failed to get attribute provider: %w", err)
	}

	// Ask explicitly for memberOf groups
	attrs, err := attrProvider.Query(username, []string{"memberOf"})
	if err != nil {
		return nil, fmt.Errorf("failed to query attributes: %w", err)
	}

	memberOfStr, ok := attrs["memberOf"]
	api.Logger().Debug("ldap-search","Groups retrieved: "+memberOfStr)
	if !ok {
		return nil, fmt.Errorf("no 'memberOf' attribute found for user")
	}

	// Split and trim group names
	groupNames := strings.Split(memberOfStr, ",")
	for i := range groupNames {
		groupNames[i] = strings.TrimSpace(groupNames[i])
	}
api.Logger().Debug("ldap-search","Filtering on: "+filter)
	// Filter group names using the 'filter' value (case-insensitive)
	var memberOf []string
	for _, group := range groupNames {
		if strings.Contains(strings.ToLower(group), strings.ToLower(filter)) {
			memberOf = append(memberOf, group)
		}
	}

	result := map[string]map[string]interface{}{
		dn: {
			"memberOf": memberOf,
		},
	}

	api.Logger().Debug(
		"msg", "search request processed",
		"dn", dn,
		"filter", filter,
		"memberOf", strings.Join(memberOf, ","),
	)
	return result, nil
}
func parseUsernameFromDN(dn string) (string, error) {
	splitDN := strings.Split(dn, ",")
	if len(splitDN) <= 1 {
		return "", errors.New("failed to split DN")
	}

	username := strings.TrimPrefix(splitDN[0], fmt.Sprintf("%s=", usernameSearchKey))
	if len(username) == 0 {
		return "", errors.New("failed to parse username from DN")
	}

	return username, nil
}