package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

const (
	expectedSearchBase = "ou=users,dc=example,dc=com"
	usernameSearchKey  = "cn"
)
type GraphConfig struct {
	TokenEndpoint   string `json:"tokenEndpoint"`
	ClientIDKey     string `json:"clientIDKey"`
	ClientSecretKey string `json:"clientSecretKey"`
	Scope           string `json:"scope"`
	BaseURL         string `json:"baseURL"`
}

type KeycloakConfig struct {
	Realm           string `json:"realm"`
	BaseURL         string `json:"baseURL"`
	ClientIDKey     string `json:"clientIDKey"`
	ClientSecretKey string `json:"clientSecretKey"`
}
type GraphClient struct {
	httpClient *http.Client
	baseURL    string
	token      string
	api        orchestrator.Orchestrator
}
func decodeJSONConfig[T any](raw any, out *T) error {
	switch v := raw.(type) {
	case map[string]any:
		b, err := json.Marshal(v)
		if err != nil {
			return fmt.Errorf("marshal map: %w", err)
		}
		return json.Unmarshal(b, out)
	case string:
		return json.Unmarshal([]byte(v), out)
	case []byte:
		return json.Unmarshal(v, out)
	default:
		return fmt.Errorf("unexpected type %T for config", raw)
	}
}
//TO DO: TEST NEW GROUP RETRIEVAL FROM GRAPH. TEST NEW KEYCLOAK CONFIG. DOCUMENT APP REG SETUP IN KEYCLOAK AND ENTRA.  MAKE GENERIC TO ALLOW FOR ROUTING TO MULTIPLE ENTRA CONFIGURATIONS - ADD A BREADCRUMB TO EACH CONFIG. ADD ABILITY TO RETURN ADDITIONAL ATTRIBUTES TO TAK SEARCH (CALLSIGN, COLOR, ETC..)
func Search(api orchestrator.Orchestrator, dn string, filter string, reqAttrs []string) (map[string]map[string]interface{}, error) {
	api.Logger().Debug("ldap-search", "INCOMING SEARCH REQUEST", "DN", dn, "Filter", filter)
	metadata := api.Metadata()
	primeIDP := metadata["PRIMARY_IDENTITY_PROVIDER"].(string)
	if !strings.Contains(dn, expectedSearchBase) {
		return nil, fmt.Errorf("received request for DN '%s', but expected search base is '%s'", dn, expectedSearchBase)
	}

	username, err := parseUsernameFromDN(dn)
	if err != nil {
		return nil, err
	}

	api.Logger().Debug("ldap-search", "Parsed username", "username", username)
    idp,_ := api.IdentityProvider(primeIDP)
	var groupNames []string
	entraHealthy := idp.IsAvailable()
	if entraHealthy {
		api.Logger().Info("ldap-search", "Entra is healthy, using Graph API")
		graphClient, err := NewGraphClient(api)
		if err == nil {
			var groupIDs []string
			groupIDs, err = graphClient.GetUserGroupIDs(username)
			if err == nil {
				api.Logger().Debug("ldap-search", "Retrieved group IDs", "count", len(groupIDs))
				groupNames, err = graphClient.ResolveGroupNames(groupIDs)
			}
		}
	}

	if !entraHealthy || err != nil {
		api.Logger().Info("ldap-search", "Falling back to Keycloak", "entraHealthy", entraHealthy, "entraError", err)
		groupNames, err = queryKeycloakGroups(api, username)
		if err != nil {
			return nil, fmt.Errorf("failed to retrieve groups from both Entra and Keycloak: %w", err)
		}
	}

	var memberOf []string
	for _, name := range groupNames {
	    api.Logger().Debug("ldap-search", "Adding group: "+name)
	//	if strings.Contains(strings.ToLower(name), strings.ToLower(filter)) {
			memberOf = append(memberOf, name)
	//	}
	}

	result := map[string]map[string]interface{}{
		dn: {
			"memberOf": memberOf,
		},
	}

	api.Logger().Debug("ldap-search", "Final result", "memberOf", strings.Join(memberOf, ", "))
	return result, nil
}

func parseUsernameFromDN(dn string) (string, error) {
	splitDN := strings.Split(dn, ",")
	if len(splitDN) <= 1 {
		return "", errors.New("failed to split DN")
	}

	username := strings.TrimPrefix(splitDN[0], fmt.Sprintf("%s=", usernameSearchKey))
	if len(username) == 0 {
		return "", errors.New("failed to parse username from DN")
	}
	return username, nil
}

func NewGraphClient(api orchestrator.Orchestrator) (*GraphClient, error) {
	metadata := api.Metadata()
	secretProvider, err := api.SecretProvider()
	if err != nil {
		return nil, fmt.Errorf("could not load secret provider - unable to get credentials for group request: %w", err)
	}

	var cfg GraphConfig
	if err := decodeJSONConfig(metadata["GRAPH_CONFIG"], &cfg); err != nil {
		return nil, fmt.Errorf("invalid GRAPH_CONFIG: %w", err)
	}

	clientID := secretProvider.GetString(cfg.ClientIDKey)
	clientSecret := secretProvider.GetString(cfg.ClientSecretKey)

	form := url.Values{}
	form.Set("client_id", clientID)
	form.Set("client_secret", clientSecret)
	form.Set("grant_type", "client_credentials")
	form.Set("scope", cfg.Scope)

	resp, err := http.PostForm(cfg.TokenEndpoint, form)
	if err != nil {
		return nil, fmt.Errorf("failed to request token: %w", err)
	}
	defer resp.Body.Close()

	var tokenResp struct {
		AccessToken string `json:"access_token"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&tokenResp); err != nil {
		return nil, fmt.Errorf("failed to decode token: %w", err)
	}

	return &GraphClient{
		httpClient: &http.Client{Timeout: 10 * time.Second},
		baseURL:    cfg.BaseURL,
		token:      tokenResp.AccessToken,
		api:        api,
	}, nil
}

func (g *GraphClient) GetUserGroupIDs(userPrincipalName string) ([]string, error) {
	
	metadata := g.api.Metadata()
	logger := g.api.Logger()
    graphAttrProvider, err := g.api.AttributeProvider(metadata["GRAPH_ATTRIBUTE_PROVIDER"].(string))
	if err != nil {
		logger.Error(
			"se", "failed to retrieve LDAP attribute provider",
			"error", err.Error(),
		)
	}
	attrs, err := graphAttrProvider.Query(
		userPrincipalName,
		[]string{"groups"},
	)
	if err != nil {
		logger.Error(
			"se", "failed to query LDAP",
			"error", err.Error(),
		)
    }
    return strings.Split(attrs["groups"],","), nil
}
func (g *GraphClient) ResolveGroupNames(groupIDs []string) ([]string, error) {
	if len(groupIDs) == 0 {
		return []string{}, nil
	}

	const maxBatchSize = 20
	var allGroupNames []string

	for i := 0; i < len(groupIDs); i += maxBatchSize {
		end := i + maxBatchSize
		if end > len(groupIDs) {
			end = len(groupIDs)
		}
		chunk := groupIDs[i:end]

		var batchRequests []map[string]interface{}
		for idx, id := range chunk {
			batchRequests = append(batchRequests, map[string]interface{}{
				"id":     fmt.Sprintf("%d", idx),
				"method": "GET",
				"url":    fmt.Sprintf("/groups/%s?$select=displayName", id),
			})
		}

		payload := map[string]interface{}{"requests": batchRequests}
		var buf bytes.Buffer
		if err := json.NewEncoder(&buf).Encode(payload); err != nil {
			return nil, fmt.Errorf("failed to encode batch request: %w", err)
		}

		req, _ := http.NewRequest("POST", g.baseURL+"/$batch", &buf)
		req.Header.Set("Authorization", "Bearer "+g.token)
		req.Header.Set("Content-Type", "application/json")

		resp, err := g.httpClient.Do(req)
		if err != nil {
			return nil, fmt.Errorf("batch request failed: %w", err)
		}
		defer resp.Body.Close()

		if resp.StatusCode != http.StatusOK {
			body, _ := io.ReadAll(resp.Body)
			return nil, fmt.Errorf("batch request failed: %s", string(body))
		}

		var batchResp struct {
			Responses []struct {
				ID     string `json:"id"`
				Status int    `json:"status"`
				Body   struct {
					DisplayName string `json:"displayName"`
				} `json:"body"`
			} `json:"responses"`
		}
		if err := json.NewDecoder(resp.Body).Decode(&batchResp); err != nil {
			return nil, fmt.Errorf("failed to decode batch response: %w", err)
		}

		for _, r := range batchResp.Responses {
			if r.Status == http.StatusOK {
				allGroupNames = append(allGroupNames, r.Body.DisplayName)
			} else {
				g.api.Logger().Error("graph-client", "Batch group lookup failed", "id", r.ID, "status", r.Status)
			}
		}
	}

	return allGroupNames, nil
}

func queryKeycloakGroups(api orchestrator.Orchestrator, username string) ([]string, error) {
	logger := api.Logger()
	metadata := api.Metadata()
	secretProvider, err := api.SecretProvider()
	if err != nil {
		return nil, fmt.Errorf("could not load secret provider - unable to get credentials for group request: %w", err)
	}

	var kc KeycloakConfig
	if err := decodeJSONConfig(metadata["KEYCLOAK_CONFIG"], &kc); err != nil {
		return nil, fmt.Errorf("invalid KEYCLOAK_CONFIG: %w", err)
	}

	realm := kc.Realm
	baseURL := kc.BaseURL
	clientID := secretProvider.GetString(kc.ClientIDKey)
	clientSecret := secretProvider.GetString(kc.ClientSecretKey)

	form := url.Values{}
	form.Set("grant_type", "client_credentials")
	form.Set("client_id", clientID)
	form.Set("client_secret", clientSecret)
	form.Set("scope", "openid")
	tokenEndpoint := fmt.Sprintf("%s/realms/%s/protocol/openid-connect/token", baseURL, realm)

	resp, err := http.PostForm(tokenEndpoint, form)
	if err != nil {
		logger.Error("keycloak-lookup", "Token request failed", "error", err)
		return nil, fmt.Errorf("Keycloak token request failed: %w", err)
	}
	defer resp.Body.Close()

	var tokenResp struct {
		AccessToken string `json:"access_token"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&tokenResp); err != nil {
		logger.Error("keycloak-lookup", "Failed to decode token response", "error", err)
		return nil, fmt.Errorf("failed to decode Keycloak token: %w", err)
	}

	userURL := fmt.Sprintf("%s/admin/realms/%s/users?username=%s", baseURL, realm, url.QueryEscape(username))
	userReq, err := http.NewRequest("GET", userURL, nil)
	if err != nil {
		logger.Error("keycloak-lookup", "Failed to build user lookup request", "error", err)
		return nil, err
	}
	userReq.Header.Set("Authorization", "Bearer "+tokenResp.AccessToken)

	client := &http.Client{Timeout: 10 * time.Second}
	userResp, err := client.Do(userReq)
	if err != nil {
		logger.Error("keycloak-lookup", "User lookup request failed", "error", err)
		return nil, fmt.Errorf("Keycloak user lookup failed: %w", err)
	}
	defer userResp.Body.Close()

	var users []struct {
		ID string `json:"id"`
	}
	if err := json.NewDecoder(userResp.Body).Decode(&users); err != nil {
		return nil, fmt.Errorf("failed to decode Keycloak user list: %w", err)
	}
	if len(users) == 0 {
		return nil, fmt.Errorf("no user found in Keycloak for username: %s", username)
	}

	groupURL := fmt.Sprintf("%s/admin/realms/%s/users/%s/groups", baseURL, realm, users[0].ID)
	groupReq, err := http.NewRequest("GET", groupURL, nil)
	if err != nil {
		return nil, err
	}
	groupReq.Header.Set("Authorization", "Bearer "+tokenResp.AccessToken)

	groupResp, err := client.Do(groupReq)
	if err != nil {
		return nil, fmt.Errorf("Keycloak group lookup failed: %w", err)
	}
	defer groupResp.Body.Close()

	var groups []struct {
		Name string `json:"name"`
	}
	if err := json.NewDecoder(groupResp.Body).Decode(&groups); err != nil {
		return nil, fmt.Errorf("failed to decode Keycloak group list: %w", err)
	}

	var groupNames []string
	for _, g := range groups {
		groupNames = append(groupNames, g.Name)
	}
	return groupNames, nil
}
