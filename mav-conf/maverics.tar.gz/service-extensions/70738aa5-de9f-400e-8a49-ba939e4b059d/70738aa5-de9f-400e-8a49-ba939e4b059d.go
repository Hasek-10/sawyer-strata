package main

import (
	"io"
	"net/http"
	"sync"

	"github.com/strata-io/service-extension/orchestrator"
)

// Global variable to store the state of the big-red-button. I like turtles
var (
	bigRedButtonState = "Up"
	mu                sync.Mutex // To ensure safe access to bigRedButtonState
)

// Handler for the /get endpoint
func handler(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	io.WriteString(w, bigRedButtonState)
}

// Handler for the /big-red-button endpoint
func bigRedButtonHandler(api orchestrator.Orchestrator) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()

		// Toggle the state between "Up" and "Down"
		if bigRedButtonState == "Up" {
			bigRedButtonState = "Down"
		} else {
			bigRedButtonState = "Up"
		}

		// Log the state change
		api.Logger().Info("Big Red Button state toggled", "newState", bigRedButtonState)

		w.WriteHeader(http.StatusOK)
		io.WriteString(w, bigRedButtonState)
	}
}

// Handler for serving static assets (HTML, CSS, images)
func staticAssetHandler(api orchestrator.Orchestrator, assetPath string, contentType string) http.HandlerFunc {
	return func(rw http.ResponseWriter, req *http.Request) {
		seAssets := api.ServiceExtensionAssets()
		assetData, err := seAssets.ReadFile(assetPath)
		if err != nil {
			http.Error(
				rw,
				err.Error(),
				http.StatusInternalServerError,
			)
			return
		}
		rw.Header().Set("Content-Type", contentType)
		rw.Write(assetData)
	}
}

// Serve the assets and routes
func Serve(api orchestrator.Orchestrator) error {
	router := api.Router()

	// Serve the Strata logo
	err := router.HandleFunc("/static/Strata_Logo.png", staticAssetHandler(api, "Strata_Logo_PRIMARY_Tag_Horizontal_Full-colorSmall.png", "image/png"))
	if err != nil {
		return err
	}

	// Serve the CSS file
	err = router.HandleFunc("/static/styles.css", staticAssetHandler(api, "styles.css", "text/css"))
	if err != nil {
		return err
	}

	// Serve the SVG files
	err = router.HandleFunc("/static/infographics.svg", staticAssetHandler(api, "infographics.svg", "image/svg+xml"))
	if err != nil {
		return err
	}

	err = router.HandleFunc("/static/infographic.svg", staticAssetHandler(api, "infographic.svg", "image/svg+xml"))
	if err != nil {
		return err
	}
	// Serve the Commercial SVG diagram
	err = router.HandleFunc("/Commercial.svg", staticAssetHandler(api, "Commercial.svg", "image/svg+xml"))
	if err != nil {
		return err
	}
	// Serve the PNG infographic
	err = router.HandleFunc("/static/infographic.png", staticAssetHandler(api, "infographic.png", "image/png"))
	if err != nil {
		return err
	}
		// Serve the PNG infographic
	err = router.HandleFunc("/infographic.png", staticAssetHandler(api, "infographic.png", "image/png"))
	if err != nil {
		return err
	}

	// Register the /big-red-button endpoint for toggling state
	err = router.HandleFunc("/big-red-button", bigRedButtonHandler(api))
	if err != nil {
		return err
	}

	// Register the /get endpoint
	err = router.HandleFunc("/get", handler)
	if err != nil {
		return err
	}

	// Serve the HTML page
	err = router.HandleFunc("/toggle-health-state", staticAssetHandler(api, "connection-state.html", "text/html"))
	if err != nil {
		return err
	}

	return nil
}
