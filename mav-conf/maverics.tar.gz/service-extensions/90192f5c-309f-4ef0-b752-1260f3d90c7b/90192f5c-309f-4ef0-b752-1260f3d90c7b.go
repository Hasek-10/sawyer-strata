package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

const (
	expectedSearchBase = "ou=users,dc=example,dc=com"
	usernameSearchKey  = "cn"

	entraTokenEndpoint = "https://login.microsoftonline.com/2eeef3fb-4a94-4a6b-a18f-22f53553f182/oauth2/v2.0/token"
	clientIDKey        = "azureOAuthClientID"
	clientSecretKey    = "azureOAuthClientSecret"

	kcTokenEndpoint   = "https://keycloak.stratademo.io/realms/mini-id/protocol/openid-connect/token"
	kcClientIDKey     = "kcOAuthClientID"
	kcClientSecretKey = "kcOAuthClientSecret"
	
	coalitiontokenEndpoint   = "https://login.microsoftonline.com/db944d07-02a7-4ce4-a56e-fcb35b6d8d05/oauth2/v2.0/token"
    coalitionclientIDKey     = "coalitionOAuthClientID"
	coalitionclientSecretKey = "coalitionOAuthClientSecret"
)

type GraphClient struct {
	httpClient *http.Client
	baseURL    string
	token      string
	api        orchestrator.Orchestrator
}

func Search(api orchestrator.Orchestrator, dn string, filter string, reqAttrs []string) (map[string]map[string]interface{}, error) {
	api.Logger().Info("ldap-search", "INCOMING SEARCH REQUEST", "DN", dn, "Filter", filter)
	metadata := api.Metadata()
	healthStatusEndpoint := metadata["HEALTH_STATUS_ENDPOINT"].(string)
	if !strings.Contains(dn, expectedSearchBase) {
		return nil, fmt.Errorf("received request for DN '%s', but expected search base is '%s'", dn, expectedSearchBase)
	}

	username, err := parseUsernameFromDN(dn)
	if err != nil {
		return nil, err
	}

	api.Logger().Info("ldap-search", "Parsed username", "username", username)

	var groupNames []string
	entraHealthy := isEntraHealthy(api, healthStatusEndpoint)
	if entraHealthy {
		api.Logger().Info("ldap-search", "Entra is healthy, using Graph API")
		graphClient, err := NewGraphClient(api, username)
		if err == nil {
			var groupIDs []string
			groupIDs, err = graphClient.GetUserGroupIDs(api, username)
			if err == nil {
				api.Logger().Debug("ldap-search", "Retrieved group IDs", "count", len(groupIDs))
				groupNames, err = graphClient.ResolveGroupNames(groupIDs)
			}
			if err != nil{
                return nil, fmt.Errorf("failed to retrieve groups from Entra graph: %w", err)
			}
		}
	}

	if !entraHealthy || err != nil {
		api.Logger().Info("ldap-search", "Falling back to Keycloak", "entraHealthy", entraHealthy, "entraError", err)
		groupNames, err = queryKeycloakGroups(api, username)
		if err != nil {
			return nil, fmt.Errorf("failed to retrieve groups from both Entra and Keycloak: %w", err)
		}
	}
	takPrefix := metadata["TAK_GROUP_PREFIX"].(string)
	var memberOf []string
	for _, name := range groupNames {
	    api.Logger().Info("ldap-search", "Adding group: "+name)
		if strings.HasPrefix(name, takPrefix) {
			memberOf = append(memberOf, name)
		}
	}

	result := map[string]map[string]interface{}{
		dn: {
			"memberOf": memberOf,
		},
	}

	api.Logger().Info("ldap-search", "Final result", "memberOf", strings.Join(memberOf, ", "))
	return result, nil
}

func parseUsernameFromDN(dn string) (string, error) {
	splitDN := strings.Split(dn, ",")
	if len(splitDN) <= 1 {
		return "", errors.New("failed to split DN")
	}

	username := strings.TrimPrefix(splitDN[0], fmt.Sprintf("%s=", usernameSearchKey))
	if len(username) == 0 {
		return "", errors.New("failed to parse username from DN")
	}
	return username, nil
}

func NewGraphClient(api orchestrator.Orchestrator, username string) (*GraphClient, error) {
    secretProvider, err := api.SecretProvider()
    logger := api.Logger()
    if err != nil {
        return nil, fmt.Errorf("could not load secret provider - unable to get credentials for group request: %w", err)
    }

    // Determine if "ocgddil" is in the username
    useCoalition := strings.Contains(strings.ToLower(username), "ocgddil")

    var clientID, clientSecret, tokenEndpoint, graphBaseURL string
    form := url.Values{}
    if useCoalition {
        logger.Info("ldap-search", "Coalition user detected")
        clientID = secretProvider.GetString(coalitionclientIDKey)
        clientSecret = secretProvider.GetString(coalitionclientSecretKey)
        tokenEndpoint = coalitiontokenEndpoint
        graphBaseURL = "https://graph.microsoft.com/v1.0"
        form.Set("scope", "https://graph.microsoft.com/.default")
    } else {
        logger.Info("ldap-search", "MCHMR user detected")
        clientID = secretProvider.GetString(clientIDKey)
        clientSecret = secretProvider.GetString(clientSecretKey)
        tokenEndpoint = entraTokenEndpoint
        graphBaseURL = "https://graph.microsoft.com/v1.0"
        form.Set("scope", "https://graph.microsoft.com/.default")
    }

    form.Set("client_id", clientID)
    form.Set("client_secret", clientSecret)
    form.Set("grant_type", "client_credentials")
  //  form.Set("scope", "https://graph.microsoft.us/.default")

    resp, err := http.PostForm(tokenEndpoint, form)
    if err != nil {
        return nil, fmt.Errorf("failed to request token: %w", err)
    }
    defer resp.Body.Close()

    var tokenResp struct {
        AccessToken string `json:"access_token"`
    }
    if err := json.NewDecoder(resp.Body).Decode(&tokenResp); err != nil {
        return nil, fmt.Errorf("failed to decode token: %w", err)
    }

    return &GraphClient{
        httpClient: &http.Client{Timeout: 10 * time.Second},
        baseURL:    graphBaseURL,
        token:      tokenResp.AccessToken,
    }, nil
}

func isEntraHealthy(api orchestrator.Orchestrator, healthEndpoint string) bool {
    logger := api.Logger()
	client := &http.Client{Timeout: 5 * time.Second}
	resp, err := client.Get(healthEndpoint)
	if err != nil {
        logger.Info("ldap-search", "Error querying Entra health endpoint","Error",err)
		return false
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
        logger.Info("ldap-search", "Status code was not 200")
		return false
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
        logger.Info("ldap-search", "Unable to read health response body")
		return false
	}
	return strings.TrimSpace(string(body)) == "Up"
}

func (g *GraphClient) GetUserGroupIDs(api orchestrator.Orchestrator, userPrincipalName string) ([]string, error) {
	endpoint := fmt.Sprintf("%s/users/%s/getMemberGroups", g.baseURL, url.PathEscape(userPrincipalName))

	reqBody := map[string]interface{}{
		"securityEnabledOnly": false,
	}
	var buf bytes.Buffer
	if err := json.NewEncoder(&buf).Encode(reqBody); err != nil {
		return nil, fmt.Errorf("failed to encode request body: %w", err)
	}

	req, _ := http.NewRequest("POST", endpoint, &buf)
	req.Header.Set("Authorization", "Bearer "+g.token)
	req.Header.Set("Content-Type", "application/json")

	resp, err := g.httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("getMemberGroups error: %s", string(body))
	}

	var result struct {
		Value []string `json:"value"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	return result.Value, nil
}

func (g *GraphClient) ResolveGroupNames(groupIDs []string) ([]string, error) {
	if len(groupIDs) == 0 {
		return []string{}, nil
	}

	const maxBatchSize = 20
	var allGroupNames []string

	for i := 0; i < len(groupIDs); i += maxBatchSize {
		end := i + maxBatchSize
		if end > len(groupIDs) {
			end = len(groupIDs)
		}
		chunk := groupIDs[i:end]

		var batchRequests []map[string]interface{}
		for idx, id := range chunk {
			batchRequests = append(batchRequests, map[string]interface{}{
				"id":     fmt.Sprintf("%d", idx),
				"method": "GET",
				"url":    fmt.Sprintf("/groups/%s?$select=displayName", id),
			})
		}
		payload := map[string]interface{}{ "requests": batchRequests }

		var buf bytes.Buffer
		if err := json.NewEncoder(&buf).Encode(payload); err != nil {
			return nil, fmt.Errorf("failed to encode batch request: %w", err)
		}

		req, _ := http.NewRequest("POST", g.baseURL+"/$batch", &buf)
		req.Header.Set("Authorization", "Bearer "+g.token)
		req.Header.Set("Content-Type", "application/json")

		resp, err := g.httpClient.Do(req)
		if err != nil {
			return nil, fmt.Errorf("batch request failed: %w", err)
		}
		defer resp.Body.Close()

		if resp.StatusCode != http.StatusOK {
			body, _ := io.ReadAll(resp.Body)
			return nil, fmt.Errorf("batch request failed: %s", string(body))
		}

		var batchResp struct {
			Responses []struct {
				ID     string `json:"id"`
				Status int    `json:"status"`
				Body   struct {
					DisplayName string `json:"displayName"`
				} `json:"body"`
			} `json:"responses"`
		}
		if err := json.NewDecoder(resp.Body).Decode(&batchResp); err != nil {
			return nil, fmt.Errorf("failed to decode batch response: %w", err)
		}

		for _, r := range batchResp.Responses {
			if r.Status == http.StatusOK {
				allGroupNames = append(allGroupNames, r.Body.DisplayName)
			} else {
				g.api.Logger().Error("graph-client", "Batch group lookup failed", "id", r.ID, "status", r.Status)
			}
		}
	}
	return allGroupNames, nil
}

func queryKeycloakGroups(api orchestrator.Orchestrator, username string) ([]string, error) {
	logger := api.Logger()
	metadata := api.Metadata()
	realm := metadata["KEYCLOAK_REALM"].(string)
	
	logger.Info("keycloak-lookup", "Starting Keycloak group query", "username", username)
    secretProvider,err := api.SecretProvider()
	if err != nil {
		return nil, fmt.Errorf("could not load secret provider - unable to get credentials for group request: %w", err)
	}
	clientID := secretProvider.GetString(kcClientIDKey)
	clientSecret := secretProvider.GetString(kcClientSecretKey)

	logger.Debug("keycloak-lookup", "Retrieved Keycloak client credentials")

	form := url.Values{}
	form.Set("grant_type", "client_credentials")
	form.Set("client_id", clientID)
	form.Set("client_secret", clientSecret)
	form.Set("scope", "openid")
    tokenEndpoint := fmt.Sprintf("https://keycloak.stratademo.io/realms/%s/protocol/openid-connect/token", realm)
	logger.Debug("keycloak-lookup", "Requesting Keycloak access token")
	resp, err := http.PostForm(tokenEndpoint, form)
	if err != nil {
		logger.Error("keycloak-lookup", "Token request failed", "error", err)
		return nil, fmt.Errorf("Keycloak token request failed: %w", err)
	}
	defer resp.Body.Close()

	var tokenResp struct {
		AccessToken string `json:"access_token"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&tokenResp); err != nil {
		logger.Error("keycloak-lookup", "Failed to decode token response", "error", err)
		return nil, fmt.Errorf("failed to decode Keycloak token: %w", err)
	}

	logger.Info("keycloak-lookup", "Token acquired, querying user")
    userURL := fmt.Sprintf("https://keycloak.stratademo.io/admin/realms/%s/users?username=%s", realm, url.QueryEscape(username))
	userReq, err := http.NewRequest("GET", userURL, nil)
	if err != nil {
		logger.Error("keycloak-lookup", "Failed to build user lookup request", "error", err)
		return nil, err
	}
	userReq.Header.Set("Authorization", "Bearer "+tokenResp.AccessToken)

	client := &http.Client{Timeout: 10 * time.Second}
	userResp, err := client.Do(userReq)
	if err != nil {
		logger.Error("keycloak-lookup", "User lookup request failed", "error", err)
		return nil, fmt.Errorf("Keycloak user lookup failed: %w", err)
	}
	defer userResp.Body.Close()

	logger.Info("keycloak-lookup", "User response received, decoding")
	var raw json.RawMessage
	if err := json.NewDecoder(userResp.Body).Decode(&raw); err != nil {
		logger.Error("keycloak-lookup", "Failed to decode user response body", "error", err)
		return nil, fmt.Errorf("failed to read Keycloak user response body: %w", err)
	}

	var users []struct {
		ID string `json:"id"`
	}
	if err := json.Unmarshal(raw, &users); err != nil {
		var errObj map[string]interface{}
		if json.Unmarshal(raw, &errObj) == nil {
			logger.Error("keycloak-lookup", "Unexpected object response from Keycloak", "response", errObj)
			return nil, fmt.Errorf("unexpected response from Keycloak: %+v", errObj)
		}
		logger.Error("keycloak-lookup", "Failed to decode Keycloak user list", "error", err)
		return nil, fmt.Errorf("failed to decode Keycloak user list: %w", err)
	}

	if len(users) == 0 {
		logger.Info("keycloak-lookup", "No user found for provided username", "username", username)
		return nil, fmt.Errorf("no user found in Keycloak for username: %s", username)
	}

	logger.Info("keycloak-lookup", "User found, querying groups", "userID", users[0].ID)
	groupURL := fmt.Sprintf("https://keycloak.stratademo.io/admin/realms/%s/users/%s/groups", realm, users[0].ID)
	groupReq, err := http.NewRequest("GET", groupURL, nil)
	if err != nil {
		logger.Error("keycloak-lookup", "Failed to build group request", "error", err)
		return nil, err
	}
	groupReq.Header.Set("Authorization", "Bearer "+tokenResp.AccessToken)

	groupResp, err := client.Do(groupReq)
	if err != nil {
		logger.Error("keycloak-lookup", "Group lookup request failed", "error", err)
		return nil, fmt.Errorf("Keycloak group lookup failed: %w", err)
	}
	defer groupResp.Body.Close()

	logger.Info("keycloak-lookup", "Group response received, decoding")
	var groups []struct {
		Name string `json:"name"`
	}
	if err := json.NewDecoder(groupResp.Body).Decode(&groups); err != nil {
		logger.Error("keycloak-lookup", "Failed to decode group list", "error", err)
		return nil, fmt.Errorf("failed to decode Keycloak group list: %w", err)
	}

	logger.Info("keycloak-lookup", "Group list decoded successfully", "groupCount", len(groups))
	var groupNames []string
	for _, g := range groups {
		groupNames = append(groupNames, g.Name)
	}
	return groupNames, nil
}
