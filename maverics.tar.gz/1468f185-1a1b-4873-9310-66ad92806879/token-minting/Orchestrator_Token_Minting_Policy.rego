package orchestrator

########################
# Token-Minting Policy for Maverics OAuth2 Server
#
# This policy assumes the OIDC provider has already validated:
# - Client credentials are correct
# - Requested scopes are registered/valid for the client
# - Grant type is allowed for the client
#
# This policy enforces ADDITIONAL authorization rules:
# - Audience-based scope restrictions
# - Token exchange (RFC 8693) scope narrowing
# - Actor chain depth restrictions for delegated tokens
#
# Available input parameters from Maverics:
# input.request.oauth.client_id
# input.request.oauth.grant_type
# input.request.oauth.scope
# input.request.oauth.audience
# input.request.oauth.response.access_token.claims (for token exchange/authorization_code)
# input.request.oauth.response.expires_in
########################

# Default deny
default result := {
	"allowed": false,
	"internal_message": "access denied by default policy",
	"external_message": "Access Denied",
}

########################
# Configuration
########################

# Clients allowed to perform token exchange (delegation)
token_exchange_clients := ["loan-orchestrator-client", "api-gateway", "service-mesh-proxy"]

# Trusted internal services (can maintain full privileges in delegation chains)
trusted_services := ["loan-orchestrator-client", "fraud-detector", "loan-admin-console"]

# Audience -> Maximum allowed scopes mapping
# If a token is being minted for a specific audience, it can only have these scopes
audience_max_scopes := {
	"fraud-detector": ["read:transactions", "read:fraud-signals", "write:fraud-alerts","read:profile"],
	"loan-admin-console": ["admin:*", "audit:loan_request", "apply:loan"],
	"mobile-portal": ["read:loan_status", "read:profile"],
	"credit-bureau": ["ssn:lookup", "credit-score:request"],
}

########################
# Helpers
########################

# Normalize scopes to an array
normalize_scopes(null) := []

normalize_scopes(x) := x if {
	is_array(x)
}

normalize_scopes(x) := [s | some s in split(x, " ")] if {
	not is_array(x)
	x != null
}

requested_scopes := normalize_scopes(input.request.oauth.scope)

# Check if scope matches allowed (supports admin:* wildcard)
scope_allowed_by(scope, allowed_set) if {
	some allowed in allowed_set
	allowed == scope
}

scope_allowed_by(scope, allowed_set) if {
	startswith(scope, "admin:")
	some allowed in allowed_set
	allowed == "admin:*"
}

# Check if all requested scopes are in allowed set
scopes_subset_of(requested, allowed_set) if {
	not bad_scope_exists(requested, allowed_set)
}

bad_scope_exists(requested, allowed_set) if {
	some r in requested
	not scope_allowed_by(r, allowed_set)
}

# High-privilege scope detection
high_privilege_scope_present(scopes) if {
	some s in scopes
	regex.match(`^admin:`, s)
}

high_privilege_scope_present(scopes) if {
	some s in scopes
	s == "read:transactions"
}

high_privilege_scope_present(scopes) if {
	some s in scopes
	s == "read:fraud-signals"
}

high_privilege_scope_present(scopes) if {
	some s in scopes
	s == "write:fraud-alerts"
}

########################
# Token Exchange Helpers (when claims are present)
########################

is_token_exchange if {
	input.request.oauth.grant_type == "urn:ietf:params:oauth:grant-type:token-exchange"
}

# Parse subject token claims from response (available in token exchange flows)
subject_token_scopes := normalize_scopes(input.request.oauth.response.access_token.claims.scope) if {
	input.request.oauth.response.access_token.claims
	input.request.oauth.response.access_token.claims.scope
}

subject_token_scopes := [] if {
	not input.request.oauth.response.access_token.claims
}

subject_token_scopes := [] if {
	input.request.oauth.response.access_token.claims
	not input.request.oauth.response.access_token.claims.scope
}

# Get actor chain depth from claims (for token exchange)
actor_claims := input.request.oauth.response.access_token.claims.act if {
	input.request.oauth.response.access_token.claims
	input.request.oauth.response.access_token.claims.act
}

actor_claims := null if {
	not input.request.oauth.response.access_token.claims
}

actor_claims := null if {
	input.request.oauth.response.access_token.claims
	not input.request.oauth.response.access_token.claims.act
}

actor_chain_depth := 0 if {
	actor_claims == null
}

actor_chain_depth := 1 if {
	actor_claims != null
	not actor_claims.act
}

actor_chain_depth := 2 if {
	actor_claims != null
	actor_claims.act
	not actor_claims.act.act
}

actor_chain_depth := 3 if {
	actor_claims != null
	actor_claims.act
	actor_claims.act.act
	not actor_claims.act.act.act
}

actor_chain_depth := 4 if {
	actor_claims != null
	actor_claims.act
	actor_claims.act.act
	actor_claims.act.act.act
}

########################
# Authorization Checks
########################

# Check 1: Client credentials grant - always allowed (OIDC provider validated scopes)
valid_client_credentials if {
	input.request.oauth.grant_type == "client_credentials"
	input.request.oauth.client_id
}

# Check 2: Authorization code grant - always allowed (OIDC provider validated scopes)
valid_authorization_code if {
	input.request.oauth.grant_type == "authorization_code"
	input.request.oauth.client_id
}

# Check 3: Token exchange validation
valid_token_exchange if {
	is_token_exchange

	# Client must be authorized for token exchange
	some client in token_exchange_clients
	client == input.request.oauth.client_id

	# Requested scopes must be subset of subject token scopes (narrowing only)
	scopes_subset_of(requested_scopes, subject_token_scopes)
}

# Check 4: Audience restriction
audience_allows if {
	# No audience specified - allow
	not input.request.oauth.audience
}

audience_allows if {
	aud := input.request.oauth.audience
	aud != null

	# Check if audience has max scopes defined
	max_scopes := audience_max_scopes[aud]
	max_scopes != null

	# Requested scopes must be subset of audience's allowed scopes
	scopes_subset_of(requested_scopes, max_scopes)
}

audience_allows if {
	aud := input.request.oauth.audience
	aud != null

	# Audience not in map - allow (no restrictions for this audience)
	not audience_max_scopes[aud]
}

# Check 5: Actor chain depth restriction (for token exchange only)
actor_chain_ok if {
	# For non-token-exchange, always ok
	not is_token_exchange
}

actor_chain_ok if {
	# For token exchange with depth <= 1, always ok
	is_token_exchange
	actor_chain_depth <= 1
}

actor_chain_ok if {
	# For token exchange with depth > 1, only allow if no high-privilege scopes
	is_token_exchange
	actor_chain_depth > 1
	not high_privilege_scope_present(requested_scopes)
}

########################
# Result Rules
########################

# Allow: Client credentials grant
result := {"allowed": true, "internal_message": msg, "external_message": "Access Granted"} if {
	valid_client_credentials
	audience_allows
	msg := "client credentials grant authorized"
}

# Allow: Authorization code grant
result := {"allowed": true, "internal_message": msg, "external_message": "Access Granted"} if {
	valid_authorization_code
	audience_allows
	msg := "authorization code grant authorized"
}

# Allow: Token exchange
result := {"allowed": true, "internal_message": msg, "external_message": "Access Granted"} if {
	valid_token_exchange
	audience_allows
	actor_chain_ok
	msg := "token exchange authorized"
}

# Deny: Token exchange not allowed for this client
result := {"allowed": false, "internal_message": msg, "external_message": "Access Denied"} if {
	is_token_exchange
	not valid_token_exchange
	msg := sprintf("client %v not authorized for token exchange", [input.request.oauth.client_id])
}

# Deny: Token exchange scope expansion attempted
result := {"allowed": false, "internal_message": msg, "external_message": "Access Denied"} if {
	is_token_exchange
	subj_scopes := subject_token_scopes
	some client in token_exchange_clients
	client == input.request.oauth.client_id
	not scopes_subset_of(requested_scopes, subj_scopes)
	msg := sprintf(
		"token exchange cannot expand scopes - requested: %v, subject has: %v",
		[requested_scopes, subj_scopes],
	)
}

# Deny: Audience restriction violation (client credentials)
result := {"allowed": false, "internal_message": msg, "external_message": "Access Denied"} if {
	valid_client_credentials
	not audience_allows
	msg := sprintf(
		"audience %v restricts scopes to %v, requested: %v",
		[input.request.oauth.audience, audience_max_scopes[input.request.oauth.audience], requested_scopes],
	)
}

# Deny: Audience restriction violation (authorization code)
result := {"allowed": false, "internal_message": msg, "external_message": "Access Denied"} if {
	valid_authorization_code
	not audience_allows
	msg := sprintf(
		"audience %v restricts scopes to %v, requested: %v",
		[input.request.oauth.audience, audience_max_scopes[input.request.oauth.audience], requested_scopes],
	)
}

# Deny: Audience restriction violation (token exchange)
result := {"allowed": false, "internal_message": msg, "external_message": "Access Denied"} if {
	valid_token_exchange
	not audience_allows
	msg := sprintf(
		"audience %v restricts scopes to %v, requested: %v",
		[input.request.oauth.audience, audience_max_scopes[input.request.oauth.audience], requested_scopes],
	)
}

# Deny: Actor chain too deep for high-privilege scopes
result := {"allowed": false, "internal_message": msg, "external_message": "Access Denied"} if {
	valid_token_exchange
	audience_allows
	not actor_chain_ok
	msg := sprintf("actor chain depth %v forbids high-privilege scopes", [actor_chain_depth])
}
