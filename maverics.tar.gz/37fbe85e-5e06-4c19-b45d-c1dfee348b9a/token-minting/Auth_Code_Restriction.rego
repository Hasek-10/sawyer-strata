# This policy ensures that user-specific scopes cannot be requested via the
# client_credentials grant. Since client_credentials flows have no user context,
# scopes that imply user actions (e.g., read:profile, write:profile) are blocked.
#
# This policy only applies to client_credentials grants and will deny all other
# grant types.

package orchestrator

auth_code_grant := "authorization_code"

default result := {
	"allowed": false,
	"internal_message": "non-user scopes not allowed for authorization_code grant",
	"external_message": "invalid_scope",
}

# Allow if auth code
result := {
	"allowed": true,
	"internal_message": "",
	"external_message": "",
} if {
	input.request.oauth.grant_type == auth_code_grant
}