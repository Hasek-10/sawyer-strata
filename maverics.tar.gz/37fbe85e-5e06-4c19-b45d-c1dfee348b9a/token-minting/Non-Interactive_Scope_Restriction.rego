# This policy ensures that user-specific scopes cannot be requested via the
# client_credentials grant. Since client_credentials flows have no user context,
# scopes that imply user actions (e.g., read:profile, write:profile) are blocked.
#
# This policy only applies to client_credentials grants and will deny all other
# grant types.

package orchestrator

client_credentials_grant := "client_credentials"

default result := {
	"allowed": false,
	"internal_message": "user scopes not allowed for client_credentials grant",
	"external_message": "invalid_scope",
}

# Scopes that require a user context and are not allowed for client_credentials.
user_scopes := {
	"read:profile",
	"write:profile",
}

# Parse requested scopes from space-separated string into a set.
requested_scopes := {s | some s in split(input.request.oauth.scope, " "); s != ""}

# Scopes being requested that are user-specific.
disallowed_requested_scopes := requested_scopes & user_scopes

# Deny non-client_credentials grants.
result := {
	"allowed": false,
	"internal_message": "policy only applies to client_credentials grant",
	"external_message": "invalid_grant",
} if {
	input.request.oauth.grant_type != client_credentials_grant
}

# Allow if no user-specific scopes are requested.
result := {
	"allowed": true,
	"internal_message": "",
	"external_message": "",
} if {
	input.request.oauth.grant_type == client_credentials_grant
	print("requested_scopes:", requested_scopes)
	print("disallowed_requested_scopes:", disallowed_requested_scopes)
	count(disallowed_requested_scopes) == 0
}