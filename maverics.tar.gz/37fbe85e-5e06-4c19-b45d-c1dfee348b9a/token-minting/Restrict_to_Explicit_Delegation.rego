# This policy allows scope up-leveling during token exchange, but only for
# explicitly permitted scopes. The requesting client may request scopes beyond
# those in the subject_token, provided all new scopes are in the allowed list.
#
# For example, if subject_token has "read:account" and the client requests
# "read:account read:fraud-report", this is allowed because "read:fraud-report"
# is in the permitted delegation scopes.
#
# This policy requires an actor_token to be present for delegation to be
# allowed. This ensures that delegation is only used in the context of
# impersonation/delegation flows, not direct token exchange.
#
# This policy only applies to token exchange grants and will deny all other
# grant types.

package orchestrator

token_exchange_grant := "urn:ietf:params:oauth:grant-type:token-exchange"

default result := {
	"allowed": false,
	"internal_message": "requested scopes include unauthorized delegation",
	"external_message": "invalid_scope",
}

# Scopes that clients are explicitly allowed to request beyond subject_token scopes.
permitted_delegation_scopes := {
	"read:fraud-report",
	"write:fraud-report",
}

# Parse scopes from space-separated strings into sets.
requested_scopes := {s | some s in split(input.request.oauth.scope, " "); s != ""}
subject_scopes := {s | some s in split(input.request.oauth.subject_token.claims.scope, " "); s != ""}

# Scopes being requested that are not in the subject_token.
new_scopes := requested_scopes - subject_scopes

# Deny non-token-exchange grants.
result := {
	"allowed": false,
	"internal_message": "policy only applies to token exchange grant",
	"external_message": "invalid_grant",
} if {
	input.request.oauth.grant_type != token_exchange_grant
}

# Require actor_token for delegation.
result := {
	"allowed": false,
	"internal_message": "delegation requires actor_token",
	"external_message": "invalid_request",
} if {
	input.request.oauth.grant_type == token_exchange_grant
	input.request.oauth.actor_token.claims == null
}

# Allow if all new scopes are in the permitted delegation list.
result := {
	"allowed": true,
	"internal_message": "",
	"external_message": "",
} if {
	input.request.oauth.grant_type == token_exchange_grant
	input.request.oauth.actor_token.claims != null
	print("requested_scopes:", requested_scopes)
	print("subject_scopes:", subject_scopes)
	print("new_scopes:", new_scopes)
	count(new_scopes - permitted_delegation_scopes) == 0
}