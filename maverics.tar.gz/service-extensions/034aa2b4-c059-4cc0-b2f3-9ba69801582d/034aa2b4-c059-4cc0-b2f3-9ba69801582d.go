package main

import (
	"fmt"
	"net/http"
    "strings"
	"github.com/strata-io/service-extension/orchestrator"
	"github.com/strata-io/service-extension/idfabric"
)

const (

	// Mav UI names of the okta IDP. Change as needed
	oktaIDP = "Okta-Fastpass-Mavs-9"
	// Mav UI name of the entra IDP. Change as needed
	entraIDP = "Entra_Maverics9"
)

// LOGIN FORM HTML IS DEFINED AT THE BOTTOM OF THE FILE

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.

func IsAuthenticated(
	api orchestrator.Orchestrator,
	_ http.ResponseWriter,
	_ *http.Request,
) bool {
	logger := api.Logger()
	sess, _ := api.Session()

	logger.Debug("msg", "determining if user is authenticated")

	oktaAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", oktaIDP))
	if oktaAuthenticated == "true" {
		logger.Debug("msg", "user is authenticated with Okta. Mapping claims from Okta")

		//Additional auth0 attributes that need to be placed on the session for the application should be mapped here.
		mapClaim(api, oktaIDP+".name", "generic.SM_USER")
		mapClaim(api, oktaIDP+".email", "generic.SM_USER")
		mapClaim(api, oktaIDP+".firstName", "generic.firstname")
		mapClaim(api, oktaIDP+".lastName", "generic.lastname")
		return true
	}

	entraAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", entraIDP))
	if entraAuthenticated == "true" {
		logger.Debug("msg", "user is authenticated with Entra. Mapping claims from Entra")
		
		//Additional LDAP attributes that need to be placed on the session for the application should be mapped here.
		mapClaim(api, entraIDP+".name", "generic.SM_USER")
		mapClaim(api, entraIDP+".preferred_username", "generic.email")
		mapClaim(api, entraIDP+".given_name", "generic.firstname")
		mapClaim(api, entraIDP+".family_name", "generic.lastname")
		return true
	}

	return false
}

func mapClaim(api orchestrator.Orchestrator, oldClaim, newClaim string) {
	logger := api.Logger()
	sess, _ := api.Session()
	claimValue, _ := sess.GetString(oldClaim)
	if claimValue == "" {
		logger.Info(fmt.Sprintf("cannot map claim for %s", oldClaim))
		return
	}
	logger.Info(fmt.Sprintf("mapping new claim %s:%s", newClaim, claimValue))
	_ = sess.SetString(newClaim, claimValue)
	sess.Save()
}

// "Authenticate" authenticates the user against the IDP that maverics selects for them based on the LDAP attribute value
func Authenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
//	sess, _ := api.Session()
	logger.Info("msg", "authenticating user")

	hasIDPBeenPicked := req.FormValue("username")
	if !IsAuthenticated(api, rw, req) && len(hasIDPBeenPicked) == 0 {
		logger.Debug("se", "rendering username input form")
		_, _ = rw.Write([]byte(fmt.Sprintf(idpForm)))
		return
	}

	if req.Method != http.MethodPost {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"receieved unexpected request type '%s', expected POST",
			req.Method,
		))
		return
	}

	logger.Info("msg", "parsing form from request")
	err := req.ParseForm()
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"failed to parse form from request: %s",
			err,
		))

		return
	}

// Routing logic is currently super simple for the demo
    idp:= oktaIDP
	filterUserVal := req.Form.Get("username")
	if strings.Contains(filterUserVal, "strata-eval") {
	    idp = entraIDP
	}
// end routing logic
    hintOption := idfabric.WithLoginHint(filterUserVal)
	provider, err := api.IdentityProvider(idp)
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf("selected IDP '%s' was not found on AuthProvider", idp))
		return
	}
	provider.Login(rw, req, hintOption)
}

// idpForm is a basic form that is rendered in order to enable the user to pick which
// IDP they want to authenticate against. The markup can be styled as necessary,
// loaded from an external file, be rendered as a dynamic template, etc.
const idpForm = `
<html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Username for IDP Routing</title>
    <link rel="stylesheet" href="idpSelector.css"> </head>
<body>
    <div class="container">
        <img src="https://debtreviewawards.co.za/wp-content/uploads/2017/06/standard-bank-vector-logo.png" alt="SB Logo" class="logo"> 
		<h1>Enter Username for IDP Routing</h1>
        <form method="POST"> 
		<div class="form-group">
                
				<p>This lets us know where to send you for authentication</p>
                <label for="username">Username</label><input type="text" id="username" name="username" placeholder="eg. jdoe@accenture.com" required="">
           </div>
            <button type="submit">Submit</button>
        </form>
    </div>
<style>body {
  font-family: 'Roboto', sans-serif;
  background-color: #f5f5f5;
}

.container {
  max-width: 400px;
  margin: 0 auto;
  padding: 40px;
  border-radius: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.logo {
  max-width: 150px;
  margin-bottom: 20px;
}

h1 {
  font-size: 24px;
  margin-bottom: 10px;
}

.form-group {
  margin-bottom: 20px;
}

label {
  font-size: 16px;
  display: block;
  margin-bottom: 5px;
}
</style></body></html>
`