package main

import (
	"encoding/json"
	"fmt"
	"net/http"
    "strings"
	"github.com/strata-io/service-extension/orchestrator"
	"io"
)


type Sub_id struct{
	Format      string     `json:"format"`
	Id   string  `json:"id"`
}

type Events struct{
	Event string `json:"iss"`
	Event_Timestamp int  `json:"event_timestamp"`
}

type CAEPEvent struct {
	Iss      string     `json:"iss"`
	Jti   string  `json:"jti"`
	Iat   int  `json:"iat"`
	Aud string `json:"aud"`
	Txn int `json:"txn"`
	Sub Sub_id
	Events Events
}

func authenticate(r *http.Request,api orchestrator.Orchestrator) bool {
    var(
        metadata = api.Metadata()
        logger = api.Logger()

    )
        authHeader := r.Header.Get("Authorization")
        
        logger.Info("Authorization Header", authHeader)
        
        if authHeader == "" {
                return false
        }
        parts := strings.Split(authHeader, " ")
        if len(parts) != 2 || parts[0] != "Bearer" {
                return false
        }
        bearerToken := metadata["access_token"]
        
        return parts[1] == bearerToken
}

func Receive(api orchestrator.Orchestrator) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
       
       var(
        logger = api.Logger()

    )
	
		if !authenticate(r,api) {
                http.Error(w, "Unauthorized", http.StatusUnauthorized)
                return
        }
        
        body, err := io.ReadAll(r.Body)
	    
	    if err != nil {
		    http.Error(w, "Could not read the request body", http.StatusBadRequest)
		    return
	        }
	   defer r.Body.Close()
	   
	   var jsonBody map[string]interface{}
	   logger.Info("CAEP Event: ", body)


	if err := json.Unmarshal(body, &jsonBody); err != nil {
		http.Error(w, "Invalid JSON. Please check your JSON document.", http.StatusBadRequest)
		return
	} else {
	    w.WriteHeader(http.StatusAccepted) 
		return
	}
	   
	}
}


func Serve(api orchestrator.Orchestrator) error {

	var (
		logger = api.Logger()
		router = api.Router()
	)

	logger.Info("se", "CAEP Receiver")

	err := router.HandleFunc("/caep", Receive(api))

	if err != nil {
		return fmt.Errorf("failed to handle route: %w", err)
	}

	return nil
}

func encodeJson(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}
