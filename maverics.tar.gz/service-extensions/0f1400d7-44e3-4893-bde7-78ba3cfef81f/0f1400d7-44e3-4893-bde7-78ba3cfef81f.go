package main

import (
	"bytes"
	"container/list"
	"context"
	"encoding/gob"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"github.com/strata-io/service-extension/orchestrator"
)


type Sub_id struct{
	Format      string     `json:"format"`
	Id   string  `json:"id"`
}

type Events struct{
	Event string `json:"iss"`
	Event_Timestamp int  `json:"event_timestamp"`
}

type CAEPEvent struct {
	Iss      string     `json:"iss"`
	Jti   string  `json:"jti"`
	Iat   int  `json:"iat"`
	Aud string `json:"aud"`
	Txn int `json:"txn"`
	Sub Sub_id
	Events Events
}
type StringQueue struct {
    queue *list.List
}

func (q *StringQueue) Enqueue(str string) {
    q.queue.PushBack(&list.Element{Value: str})
}

func (q *StringQueue) Dequeue() (string, bool) {
    if q.queue.Len() == 0 {
        return "", false
    }
    e := q.queue.Front()
    str := e.Value.(string)
    q.queue.Remove(e)
    return str, true
}
func authenticate(r *http.Request,api orchestrator.Orchestrator) bool { 
	var(
        metadata = api.Metadata()
        logger = api.Logger()
    )
    authHeader := r.Header.Get("Authorization")
        
    logger.Info("Authorization Header", authHeader)
        
    if authHeader == "" {
        return false
    }
    parts := strings.Split(authHeader, " ")
    if len(parts) != 2 || parts[0] != "Bearer" {
        return false
    }
    bearerToken := metadata["access_token"]
    
    return parts[1] == bearerToken
}

func Receive(api orchestrator.Orchestrator) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
       
       var(
            logger = api.Logger()
        )
	eventCache,err := api.Cache("/caep-events")
	if err != nil{
		logger.Error("caeplistener","unable to get caep event cache!")
	}
		if !authenticate(r,api) {
                http.Error(w, "Unauthorized", http.StatusUnauthorized)
                return
        }
        
        body, err := io.ReadAll(r.Body)
	    
	   if err != nil {
		    http.Error(w, "Could not read the request body", http.StatusBadRequest)
		    return
	   }
	   defer r.Body.Close()
	   
	   var jsonBody map[string]interface{}
	   logger.Info("CAEP Event: ", body)

    	if err := json.Unmarshal(body, &jsonBody); err != nil {
    		http.Error(w, "Invalid JSON. Please check your JSON document.", http.StatusBadRequest)
    		return
    	} else {
			// Access the "events" dictionary
			events := jsonBody["eventDetails"].(map[string]interface{})["events"].(map[string]interface{}) // "Can you teach me how to parse arbitrary JSON in Go?" "I can, but it will cost your soul."

			// Iterate over each event type (key) in the "events" dictionary

			/*IF WE ARE ACTIVELY POLLING INSTEAD OF PASSIVELY LISTENING WE MAY RECEIVE A LIST OF EVENTS WITH MULTIPLE SUBJECTS - THIS PASSIVE LISTENER WILL NEED TO BE REWRITTEN FOR BETTER PERFORMANCE */
			for eventTypeName, eventData := range events {
					// Print the event type (assuming it represents the event name)
					fmt.Printf("Event Name: %s\n", eventTypeName)
	
					// Check if the event data has a "subject" key
					if subjectData, ok := eventData.(map[string]interface{})["subject"]; !ok {
							fmt.Println("Subject not found for this event.")
					} else {
							var buf bytes.Buffer					
    						enc := gob.NewEncoder(&buf)
							// Print the subject's email
							cacheKey := subjectData.(map[string]interface{})["email"].(string)
							logger.Info("caep-receiver","Subject Email: "+ cacheKey+"\n")
							userEventQueueBytes, _ := eventCache.GetBytes(context.Background(),cacheKey)
							logger.Info("caep-receiver","User Event Queue Bytes retrieved from cache")
							dBuf := bytes.NewBuffer(userEventQueueBytes)
							dec := gob.NewDecoder(dBuf)
							var q StringQueue
							err :=  dec.Decode(&q)
							if err != nil{
								logger.Error("caep-receiver","Unable to decode event queue for subject: "+cacheKey+" event(s) will not be processed!")
								return
							}
							q.Enqueue(eventTypeName)
							enc.Encode(&q)
							eventCache.SetBytes(context.Background(),cacheKey,buf.Bytes())
							logger.Info("caep-receiver","SUCCESS - EVENT:'"+eventTypeName+"' PLACED ON USER: '"+cacheKey+"' EVENT QUEUE & RETURNED TO CACHE")
					}
	
					fmt.Println("-" + strings.Repeat("-", 20)) // Print a separator between events
			}
    	    w.WriteHeader(http.StatusAccepted)
    		return
    	}
	   
	}
}


func Serve(api orchestrator.Orchestrator) error {

	var (
		logger = api.Logger()
		router = api.Router()
	)

	logger.Info("se", "CAEP Receiver")

	err := router.HandleFunc("/caep", Receive(api))

	if err != nil {
		return fmt.Errorf("failed to handle route: %w", err)
	}

	return nil
}

func encodeJson(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}
