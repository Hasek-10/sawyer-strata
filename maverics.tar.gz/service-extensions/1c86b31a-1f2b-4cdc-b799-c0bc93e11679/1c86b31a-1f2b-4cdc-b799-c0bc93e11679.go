package main

import (
	"fmt"
	"net/http"
    "strings"
    "os"
	"github.com/strata-io/service-extension/orchestrator"
	"github.com/strata-io/service-extension/idfabric"
)

const (
	// Mav UI names of the entra IDP. Change as needed
	entraWorkforceIDP = "NYC_Entra_POC"
	// Mav UI name of the entra external ID IDP. Change as needed
	entraExternalIDP = "NYC_Entra_ExternalID_POC"
	// Mav UI name of the azureb2c IDP. Change as needed
	azureB2CIDP = "NYC_AzureB2C_POC"
	//IDP Router html form path
	portalHtmlFilepath = "/etc/maverics/nycpsRouter.html"
)

// LOGIN FORM HTML IS DEFINED AT THE BOTTOM OF THE FILE - Move to using an "asset" HTML file.

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.

func IsAuthenticated(
	api orchestrator.Orchestrator,
	_ http.ResponseWriter,
	_ *http.Request,
) bool {
	logger := api.Logger()
	sess, _ := api.Session()

	logger.Debug("msg", "determining if user is authenticated")

	entraWorkforceAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", entraWorkforceIDP))
	if entraWorkforceAuthenticated == "true" {
		logger.Debug("msg", "user is authenticated with Entra Workforce. Mapping claims from Entra Workforce")

		//Additional attributes that need to be placed on the session for the application should be mapped here.
		mapClaim(api, entraWorkforceIDP+".preferred_username", "generic.preferred_username")
		mapClaim(api, entraWorkforceIDP+".email", "generic.SM_USER")
		mapClaim(api, entraWorkforceIDP+".given_name", "generic.given_name")
		mapClaim(api, entraWorkforceIDP+".family_name", "generic.family_name")
		return true
	}

	entraExternalAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", entraExternalIDP))
	if entraExternalAuthenticated == "true" {
		logger.Debug("msg", "user is authenticated with Entra External ID. Mapping claims from Entra")
		
		//Additional attributes that need to be placed on the session for the application should be mapped here.
		mapClaim(api, entraExternalIDP+".preferred_username", "generic.preferred_username")
		mapClaim(api, entraExternalIDP+".email", "generic.email")
		mapClaim(api, entraExternalIDP+".given_name", "generic.given_name")
		mapClaim(api, entraExternalIDP+".family_name", "generic.family_name")
		return true
	}
	
	azureB2CAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", azureB2CIDP))
	if azureB2CAuthenticated == "true" {
		logger.Debug("msg", "user is authenticated with Azure B2C. Mapping claims from Entra")
		
		//Additional attributes that need to be placed on the session for the application should be mapped here.
		mapClaim(api, azureB2CIDP+".preferred_username", "generic.preferred_username")
		mapClaim(api, azureB2CIDP+".email", "generic.email")
		mapClaim(api, azureB2CIDP+".given_name", "generic.given_name")
		mapClaim(api, azureB2CIDP+".family_name", "generic.family_name")
		return true
	}

	return false
}

func mapClaim(api orchestrator.Orchestrator, oldClaim, newClaim string) {
	logger := api.Logger()
	sess, _ := api.Session()
	claimValue, _ := sess.GetString(oldClaim)
	if claimValue == "" {
		logger.Info(fmt.Sprintf("cannot map claim for %s", oldClaim))
		return
	}
	logger.Info(fmt.Sprintf("mapping new claim %s:%s", newClaim, claimValue))
	_ = sess.SetString(newClaim, claimValue)
	sess.Save()
}

// "Authenticate" authenticates the user against the IDP that maverics selects for them based on the "username" attribute value
func Authenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
//	sess, _ := api.Session()
	logger.Info("msg", "authenticating user")

	hasIDPBeenPicked := req.FormValue("username")
	if !IsAuthenticated(api, rw, req) && len(hasIDPBeenPicked) == 0 {
		logger.Debug("se", "rendering username input form")
	f, err := os.ReadFile(portalHtmlFilepath)
	if err != nil {
		logger.Error("unable to read idp html form: %w", err)
		return
	}
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.Write(f)
	return
	}

	if req.Method != http.MethodPost {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"receieved unexpected request type '%s', expected POST",
			req.Method,
		))
		return
	}

	logger.Info("msg", "parsing form from request")
	err := req.ParseForm()
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"failed to parse form from request: %s",
			err,
		))

		return
	}

// Routing logic is currently super simple for the demo
    idp:= azureB2CIDP
	filterUserVal := req.Form.Get("username")
	if strings.Contains(filterUserVal, "nycdoepocoutlook.onmicrosoft") {
	    idp = entraWorkforceIDP
	}
	if strings.Contains(filterUserVal, "TrialTenantdlWCTPbu.onmicrosoft") {
	    idp = entraExternalIDP
	}
// end routing logic
    hintOption := idfabric.WithLoginHint(filterUserVal)
	provider, err := api.IdentityProvider(idp)
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf("selected IDP '%s' was not found on AuthProvider", idp))
		return
	}
	provider.Login(rw, req, hintOption)
}

// idpForm is a basic form that is rendered in order to enable the user to pick which
// IDP they want to authenticate against. The markup can be styled as necessary,
// loaded from an external file, be rendered as a dynamic template, etc.
const idpForm = `
<html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Username for IDP Routing</title>
    <link rel="stylesheet" href="idpSelector.css"> </head>
     <link rel="stylesheet" href="https://www.nycenet.edu/ui/apps/sites/sso/waves/css/sso.css" type="text/css">
<body>
    <div class="container">
        <img src="https://logodix.com/logo/686687.png" alt="NYCPS Logo" class="logo"> 
		<h1>Enter Username for IDP Routing</h1>
        <form method="POST"> 
		<div class="form-group">
                
				<p>This lets us know where to send you for authentication</p>
                <label for="username">Username</label><input type="text" id="username" name="username" placeholder="eg. jdoe@nycps.com" required="">
           </div>
            <button type="submit">Submit</button>
        </form>
    </div>
</body></html>
`