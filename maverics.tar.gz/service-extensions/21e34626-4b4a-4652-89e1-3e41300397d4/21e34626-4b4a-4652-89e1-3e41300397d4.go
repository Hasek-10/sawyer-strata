package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"

	"github.com/strata-io/service-extension/orchestrator"
)

type Application struct {
	IconURL     string `json:"icon"`
	Title       string `json:"title"`
	Description string `json:"description"`
	AppURL      string `json:"url"`
}

const (
	portalHtmlFilepath = "/etc/maverics/portal.html"
)

func Serve(api orchestrator.Orchestrator) error {
	var (
		logger   = api.Logger()
		router   = api.Router()
		metadata = api.Metadata()
	)

	logger.Info("se", "exposing custom API")

	router.HandleFunc("/appmetadata", func(rw http.ResponseWriter, req *http.Request) {

		rw.Header().Set("Content-Type", "application/json")
		payload, _ := json.Marshal(getAppMetadata(metadata))
		_, _ = fmt.Fprint(rw, payload)
		return
	})
	router.HandleFunc("/applicationportal", func(rw http.ResponseWriter, req *http.Request) {
		rw.Header().Set("Content-Type", "text/html; charset=utf-8")
		renderIDPForm(api, rw)
		return
	})

	return nil
}
func renderIDPForm(api orchestrator.Orchestrator, rw http.ResponseWriter) error {
	log := api.Logger()
	log.Info("msg", "received GET request, rendering app portal!")
	f, err := os.ReadFile(portalHtmlFilepath)
	if err != nil {
		return fmt.Errorf("unable to read idp html form: %w", err)
	}
	_, _ = rw.Write(f)
	return nil
}
func getAppMetadata(metadata map[string]any) []Application {
	serverList := []Application{
		{
			AppURL:      "https://maverics12.strata.io/CanaryBank",
			Title:       "Canary Bank",
			Description: "Manage your activities with Canary Bank",
			IconURL:     metadata["canaryIcon"].(string),
		},
		{
			AppURL:      "https://maverics12.strata.io/Sonar",
			Title:       "Sonar Systems",
			Description: "CRM for your organization with the help of Sonar Systems",
			IconURL:     metadata["sonarIcon"].(string),
		},
		//Add more as desired.
		/*{
			AppURL:      "https://maverics12.strata.io/Sonar",
			Title: "Sonar Systems",
			Description: "CRM for your organization with the help of Sonar Systems",
			IconURL:   metadata["sonarIcon"].(string),
		},*/

	}
	return serverList
}
