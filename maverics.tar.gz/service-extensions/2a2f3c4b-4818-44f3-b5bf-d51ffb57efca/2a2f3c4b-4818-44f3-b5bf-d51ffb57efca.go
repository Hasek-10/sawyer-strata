package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/go-jose/go-jose/v3/jwt"
	"github.com/google/uuid"
	"github.com/strata-io/service-extension/cache"
	"github.com/strata-io/service-extension/orchestrator"
)

const (
	oktaTokenURL              = "https://dev-473810.okta.com/oauth2/default/v1/token"
	oktaClientIDLookupKey     = "oktaROPCClientID"
	oktaClientSecretLookupKey = "oktaROPCClientSecret"
)

var clientIDsToIDPs = map[string]oidcClient{
	"examplePingID": {
		ClientID:     "examplePingID",
		ClientSecret: "examplePingSecret",
		IDP:          "ping",
	},
	"exampleOktaID": {
		ClientID:     "exampleOktaID",
		ClientSecret: "exampleOktaSecret",
		IDP:          "okta",
	},
}

func IsLoggedIn(api orchestrator.Orchestrator, _ http.ResponseWriter, req *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "determining which IDP to route request to")

	rawBody, err := io.ReadAll(req.Body)
	if err != nil {
		logger.Error(
			"se", "failed to read body",
			"error", err.Error(),
		)

		return false
	}

	req.Body = io.NopCloser(bytes.NewBuffer(rawBody))
	if err := req.ParseForm(); err != nil {
		logger.Error(
			"se", "failed to parse form",
			"error", err.Error(),
		)

		return false
	}
	req.Body = io.NopCloser(bytes.NewBuffer(rawBody))

	clientID, _ := clientCredentials(req)
	_, ok := clientIDsToIDPs[clientID]
	if !ok {
		logger.Debug(
			"se", "routing request to PingFederate for unknown client",
			"client_id", clientID,
		)
		return true
	}

	switch clientIDsToIDPs[clientID].IDP {
	case "okta":
		logger.Debug(
			"se", "routing request to Okta",
			"client_id", clientID,
		)

		// For apps that were NOT manually migrated, handle the token exchanges in
		// the Login extension.
		return false
	case "ping":
		logger.Debug(
			"se", "routing request to PingFederate",
			"client_id", clientID,
		)

		// For the apps that should authenticate against Ping, proxy the traffic
		// without interfering with the exchange. Eventually, all apps will
		// authenticate against Okta.
		return true
	}

	return true
}

func Login(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) error {
	var logger = api.Logger()
	logger.Debug("se", "handling Okta login request")

	clientID, clientSecret := clientCredentials(req)
	if clientSecret != clientIDsToIDPs[clientID].ClientSecret {
		logger.Debug(
			"se", "received request with invalid client secret",
			"client_id", clientID,
		)
		http.Error(
			rw,
			http.StatusText(http.StatusUnauthorized),
			http.StatusUnauthorized,
		)
		return nil
	}

	grantType := req.Form.Get("grant_type")
	switch grantType {
	case "password":
		return handlePasswordGrant(api, rw, req)
	case "urn:pingidentity.com:oauth2:grant_type:validate_bearer":
		return handleValidateBearerGrant(api, rw, req)
	default:
		http.Error(rw, "invalid grant_type", http.StatusBadRequest)
		logger.Info(
			"se", "received unexpected request",
			"path", req.URL.Path,
			"params", req.URL.RawQuery,
			"method", req.Method,
		)
		return nil
	}
}

func handlePasswordGrant(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) error {
	var logger = api.Logger()
	logger.Debug("se", "handling 'password' grant token request'")

	tokenCache, err := api.Cache("/oidc")
	if err != nil {
		logger.Error(
			"se", "failed to get cache",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	secretProvider, err := api.SecretProvider()
	if err != nil {
		logger.Error(
			"se", "failed to get secret provider",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	svcAcctClientID := secretProvider.GetString(oktaClientIDLookupKey)
	if len(svcAcctClientID) == 0 {
		logger.Error("se", "failed to load service account client_id")
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	svcAcctClientSecret := secretProvider.GetString(oktaClientSecretLookupKey)
	if len(svcAcctClientSecret) == 0 {
		logger.Error("se", "failed to load service account client_secret")
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	var (
		requiredROPCParams = []string{
			"username",
			"password",
			"scope",
			"grant_type",
		}
		missingParams []string
	)
	for _, param := range requiredROPCParams {
		if len(req.Form.Get(param)) == 0 {
			missingParams = append(missingParams, param)
		}
	}
	if len(missingParams) > 0 {
		http.Error(
			rw,
			fmt.Sprintf(
				"missing required params for 'password' grant: [%s]",
				strings.Join(missingParams, ", "),
			),
			http.StatusBadRequest,
		)
		return nil
	}

	formData := url.Values{}
	formData.Set("client_id", svcAcctClientID)
	formData.Set("client_secret", svcAcctClientSecret)
	formData.Set("grant_type", "password")
	formData.Set("username", req.Form.Get("username"))
	formData.Set("password", req.Form.Get("password"))
	formData.Set("scope", "openid")
	ropcReq, err := http.NewRequest(
		http.MethodPost,
		oktaTokenURL,
		strings.NewReader(formData.Encode()),
	)
	if err != nil {
		logger.Error(
			"se", "failed to create request to Okta",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}
	ropcReq.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := http.DefaultClient.Do(ropcReq)
	if err != nil {
		logger.Error(
			"se", "failed to make ROPC request to Okta",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}
	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		logger.Info(
			"se", "failed to authenticate with Okta",
			"statusCode", resp.StatusCode,
			"error", string(body),
		)
		http.Error(rw, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
		return nil
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error(
			"se", "failed to read Okta ROPC response body",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}
	defer resp.Body.Close()

	oktaTokenResponse := stdTokenResponse{}
	err = json.Unmarshal(body, &oktaTokenResponse)
	if err != nil {
		logger.Error(
			"se", "failed to unmarshal Okta ROPC response body",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	ce := cacheEntry{
		TokenResponse: oktaTokenResponse,
		Scope:         req.Form.Get("scope"),
		ExpiresAt:     time.Now().Add(time.Second * time.Duration(oktaTokenResponse.ExpiresIn)),
	}
	tokenEntry, err := json.Marshal(&ce)
	if err != nil {
		logger.Error(
			"se", "failed to read marshal cache entry",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	accessToken := uuid.New().String()
	err = tokenCache.SetBytes(
		context.Background(),
		accessToken,
		tokenEntry,
		cache.WithTTL(time.Second*time.Duration(oktaTokenResponse.ExpiresIn)),
	)
	if err != nil {
		logger.Error(
			"se", "failed to set cache data",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	tokenResponse := stdTokenResponse{
		AccessToken: accessToken,
		TokenType:   oktaTokenResponse.TokenType,
		ExpiresIn:   oktaTokenResponse.ExpiresIn,
	}

	rw.Header().Set("Content-Type", "application/json")
	err = json.NewEncoder(rw).Encode(tokenResponse)
	if err != nil {
		logger.Error(
			"se", "failed to encode token response",
			"error", err.Error(),
		)
		return nil
	}

	logger.Debug("se", "successfully handled 'password' grant token request'")
	return nil
}

func handleValidateBearerGrant(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) error {
	var logger = api.Logger()
	logger.Debug("se", "handling 'urn:pingidentity.com:oauth2:grant_type:validate_bearer' grant token request'")

	tokenCache, err := api.Cache("/oidc")
	if err != nil {
		logger.Error(
			"se", "failed to get cache",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	var (
		requiredValidateBearerParams = []string{
			"token",
			"grant_type",
		}
		missingParams []string
	)
	for _, param := range requiredValidateBearerParams {
		if len(req.Form.Get(param)) == 0 {
			missingParams = append(missingParams, param)
		}
	}
	if len(missingParams) > 0 {
		http.Error(
			rw,
			fmt.Sprintf(
				"missing required params for 'urn:pingidentity.com:oauth2:grant_type:validate_bearer' grant: [%s]",
				strings.Join(missingParams, ", "),
			),
			http.StatusBadRequest,
		)
		return nil
	}

	token := req.Form.Get("token")
	if len(token) == 0 {
		logger.Error("se", "request did not contain 'token'")
		http.Error(
			rw,
			http.StatusText(http.StatusBadRequest),
			http.StatusBadRequest,
		)
		return nil
	}

	tokenBytes, err := tokenCache.GetBytes(context.Background(), token)
	if err != nil {
		logger.Error(
			"se", "did not find token in cache",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusBadRequest),
			http.StatusBadRequest,
		)
		return nil
	}

	var oktaTokenResponse cacheEntry
	err = json.Unmarshal(tokenBytes, &oktaTokenResponse)
	if err != nil {
		logger.Error(
			"se", "failed to unmarshal okta token response",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	rawToken, err := jwt.ParseSigned(oktaTokenResponse.TokenResponse.AccessToken)
	if err != nil {
		logger.Error(
			"se", "failed to parse Okta token response",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	accessTknClaims := claims{}
	err = rawToken.UnsafeClaimsWithoutVerification(&accessTknClaims)
	if err != nil {
		logger.Error(
			"se", "failed to decode Okta token response",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return nil
	}

	if req.URL.Path == "/as/introspect.oauth2" {
		introspectResponse := pingIntrospectResponse{
			Sub:                accessTknClaims.Subject,
			Uid:                accessTknClaims.Subject,
			Clientid:           accessTknClaims.ClientID,
			Accesslevel:        "4",                  // TODO: replace hardcoded value from proper source.
			Pwdlastset:         "133525369550071827", // TODO: replace hardcoded value from proper source.
			Active:             true,
			TokenType:          "Bearer",
			Exp:                int(oktaTokenResponse.ExpiresAt.Sub(time.Now()).Seconds()),
			ClientIdUnderscore: accessTknClaims.ClientID,
		}

		rw.Header().Set("Content-Type", "application/json")
		err = json.NewEncoder(rw).Encode(introspectResponse)
		if err != nil {
			logger.Error(
				"se", "failed to encode token response",
				"error", err.Error(),
			)
		}
		return nil
	}

	validateBearerResponse := pingValidateBearerResponse{
		AccessToken: pingAccessTokenResponse{
			Sub:         accessTknClaims.Subject,
			Uid:         accessTknClaims.Subject,
			ClientID:    accessTknClaims.ClientID,
			AccessLevel: "4",                  // TODO: replace hardcoded value from proper source.
			PwdLastSet:  "133525369550071827", // TODO: replace hardcoded value from proper sourcr.
			Client_ID:   accessTknClaims.ClientID,
		},
		Scope:     oktaTokenResponse.Scope,
		ExpiresIn: int(oktaTokenResponse.ExpiresAt.Sub(time.Now()).Seconds()),
		TokenType: oktaTokenResponse.TokenResponse.TokenType,
		ClientId:  accessTknClaims.ClientID,
	}

	rw.Header().Set("Content-Type", "application/json")
	err = json.NewEncoder(rw).Encode(validateBearerResponse)
	if err != nil {
		logger.Error(
			"se", "failed to encode token response",
			"error", err.Error(),
		)
		return nil
	}

	logger.Debug("se", "successfully handled 'urn:pingidentity.com:oauth2:grant_type:validate_bearer' grant token request'")
	return nil
}

func clientCredentials(req *http.Request) (clientID, clientSecret string) {
	clientID = req.Form.Get("client_id")
	clientSecret = req.Form.Get("client_secret")
	if len(clientID) == 0 {
		clientID, clientSecret, _ = req.BasicAuth()
	}

	return clientID, clientSecret
}

type oidcClient struct {
	ClientID     string
	ClientSecret string
	IDP          string
}

type stdTokenResponse struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
}

type pingValidateBearerResponse struct {
	AccessToken pingAccessTokenResponse `json:"access_token,omitempty"`
	Scope       string                  `json:"scope,omitempty"`
	TokenType   string                  `json:"token_type,omitempty"`
	ExpiresIn   int                     `json:"expires_in,omitempty"`
	ClientId    string                  `json:"client_id,omitempty"`
}

type pingIntrospectResponse struct {
	Sub                string `json:"sub"`
	Uid                string `json:"uid"`
	Clientid           string `json:"clientid"`
	Accesslevel        string `json:"accesslevel"`
	Pwdlastset         string `json:"pwdlastset"`
	Active             bool   `json:"active"`
	TokenType          string `json:"token_type"`
	Exp                int    `json:"exp"`
	ClientIdUnderscore string `json:"client_id"`
}

type pingAccessTokenResponse struct {
	Sub         string `json:"sub,omitempty"`
	Uid         string `json:"uid,omitempty"`
	ClientID    string `json:"clientid,omitempty"`
	AccessLevel string `json:"accesslevel,omitempty"`
	PwdLastSet  string `json:"pwdlastset,omitempty"`
	Client_ID   string `json:"client_id,omitempty"`
}

type claims struct {
	Subject  string `json:"sub,omitempty"`
	ClientID string `json:"cid,omitempty"`
}

type cacheEntry struct {
	TokenResponse stdTokenResponse `json:"tokenResponse"`
	Scope         string           `json:"scope"`
	ExpiresAt     time.Time        `json:"expiresAt"`
}
