package main

import (
	"net/http"
	"bytes"
	"encoding/json"
	"fmt"
	"time"
	"errors"
	"context"
	"io/ioutil"
	"io"
	"github.com/strata-io/service-extension/orchestrator"
)
const (
    /*Keycloak JIT provisioning constants*/
	baseURL   = "https://keycloak.stratademo.io/"
	realmName = "master"
	//Get these off the session...

	// Get groups from the microsoft graph api...
	adminUsernameSecret = "Keycloak-admin-username"
	adminPasswordSecret = "Keycloak-admin-password"
	clientIDSecret = "Keycloak-admin-client"
	
	/*Maveric Constants*/
	entraConnectorName = "Entra_Maverics9"
	keycloakConnectorName = "Keycloak"
	continuityConnectorName = "Entra_Keycloak_DDIL"
	graphApiConnectorName = "Entra_Maverics9_Graph"
)

type TokenResponse struct {
	AccessToken string `json:"access_token"`
	TokenType string `json:"token_type"`
	NotBeforePolicy int `json:"not-before-policy"`
	SessionState string `json:"session_state"`
	Scope string `json:"scope"`

}

type User struct {
	Username  string `json:"username"`
	Email     string `json:"email"`
	FirstName string `json:"firstName"`
	LastName  string `json:"lastName"`
	Enabled   bool   `json:"enabled"`
}

type UserIDResponse struct {
	ID string `json:"id"`
}

func provision(api orchestrator.Orchestrator) error{
    logger := api.Logger()
    secrets, err := api.SecretProvider()
    session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return err
	}
    username,err := session.GetString(entraConnectorName+".preferred_username")
    email,err := session.GetString(entraConnectorName+".email")
    firstName,err := session.GetString(entraConnectorName+".given_name")
    lastName,err := session.GetString(entraConnectorName+".family_username")
    //store the admin bearer token here
 //   tokenCache, err := api.Cache("/provisioning-token")
    //put provisioned usernames here to minimize round trips
    

	if err != nil {
		logger.Error(
			"se", "failed to retrieve secret provider",
			"error", err.Error(),
		)
		return errors.New("failed to retrieve secret provider")
	}
	adminUsername := secrets.GetString(adminUsernameSecret)
	adminPassword := secrets.GetString(adminPasswordSecret)
	clientID := secrets.GetString(clientIDSecret)
	// Obtain an admin access token TODO: Maintain token in orchestrator cache 
	token, err := getAdminToken(api,baseURL, realmName, adminUsername, adminPassword, clientID)
	if err != nil {
		logger.Error("se-provisioner","Unable to retrieve a token for secondary user provisioning", "se-provisioner-underlying", err)
		return err
	}
    logger.Info("se-provisioner","AT="+token)
	// Check if user exists 
	userID, err := getUserID(api,baseURL, realmName, token, username)
	if err != nil {
		logger.Error("se-provisioner","Unable to determine if user is provisioned: "+username, "se-provisioner-underlying", err)
		return err
	}

	if userID != "" {
		logger.Info("se-provisioner","User already exists: "+username)
	} else {
		// Create the user
		userID, err = createUser(api, baseURL, realmName, token, username, email, firstName, lastName)
		if err != nil {
			fmt.Println(err)
			return err
		}

    groups := []string{"test-group2","test-Entra-Provisioning"}
    entraGraphAttrProvider, err := api.AttributeProvider(graphApiConnectorName)
	if err != nil {
		logger.Error(
			"se", "failed to retrieve Graph API attribute provider",
			"error", err.Error(),
		)
		return err
	}

	attrs, err := entraGraphAttrProvider.Query(
		username,
		[]string{"memberOf"},
	)
	if err != nil {
		logger.Error(
			"se", "failed to query Graph API for groups",
			"error", err.Error(),
		)
		//http.Error(
		//	rw,
		//	http.StatusText(http.StatusInternalServerError),
		//	http.StatusInternalServerError,
		//)
		return err
	}
	graphGroups := attrs[graphApiConnectorName+".memberOf"]
	logger.Info("se-group-provision","Retrieved groups: "+graphGroups)
		// Add the user to groups
		err = addUserToGroups(api, baseURL, realmName, token, userID, groups)
		if err != nil {
			fmt.Println(err)
			return err
		}

		// Force password reset on first login
		err = executeUpdatePasswordAction(api,baseURL, realmName, token, userID)
		if err != nil {
			fmt.Println(err)
			return err
		}

		fmt.Println("User created and password reset action executed successfully.")
	}
	return nil
}

func getAdminToken(api orchestrator.Orchestrator,baseURL, realmName, adminUsername, adminPassword, clientID string) (string, error) {
	url := fmt.Sprintf("%s/realms/%s/protocol/openid-connect/token", baseURL, realmName)
	data := fmt.Sprintf("username=%s&password=%s&client_id=%s&grant_type=password", adminUsername, adminPassword, clientID)
    logger := api.Logger()
	req, err := http.NewRequest("POST", url, bytes.NewBuffer([]byte(data)))
	if err != nil {
	    logger.Error("se-provisioner", "Unable to generate HTTP request")
		return "", err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	apiHttp := api.HTTP()
	
	// Attempt to retrieve an already stored client.
	client, err := apiHttp.GetClient("apiClient")
	if err != nil {
		// Create a new client if one has not already been stored.
		client = &http.Client{Timeout: time.Second * 5}
		err := apiHttp.SetClient("apiClient", client)
		if err != nil {
		    logger.Error("se-provisioner", "Unable to create HTTP client for requesting admin token!")
			return "", err
		}
	}
	resp, err := client.Do(req)
	if err != nil {
	    logger.Error("se-provisioner", "Admin Token Request failed")
		return "", err
	}
	defer resp.Body.Close()
    body, err := io.ReadAll(resp.Body)
	if err != nil {
		logger.Error("Failed to read response body: %v", err)
	}

	// Log the response body
	logger.Info("se-provisioner-RESPONSE", body)
	

	var tokenResponse TokenResponse
	err = json.NewDecoder(resp.Body).Decode(&tokenResponse)
	if err != nil {
	    logger.Error("se-provisioner", "Failed to decode admin token response")
	    return "", err
	}
    logger.Info("se-provisioner", "TESTING - AT="+tokenResponse.AccessToken)
	return tokenResponse.AccessToken, nil
}

func getUserID(api orchestrator.Orchestrator,baseURL, realmName, token, username string) (string, error) {
    logger := api.Logger()
	url := fmt.Sprintf("%s/admin/realms/%s/users?username=%s", baseURL, realmName, username)
    provisionerCache, err:=api.Cache("/provisioning-users")
    cachedBytes,err := provisionerCache.GetBytes(context.Background(), username)
    if(err != nil){
        logger.Info("User:'"+username+"' not found in cache. Checking secondary directory.")
    }
    if(len(cachedBytes) > 0){
        logger.Info("User:'"+username+"' found in cache. Returning early")
        return string(cachedBytes),nil
    }
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("Authorization", "Bearer "+token)

	apiHttp := api.HTTP()
	logger.Info("se-provisioner","Checking for user at: "+url)
	// Attempt to retrieve an already stored client.
	client, err := apiHttp.GetClient("apiClient")
	if err != nil {
		// Create a new client if one has not already been stored.
		client = &http.Client{Timeout: time.Second * 5}
		err := apiHttp.SetClient("apiClient", client)
		if err != nil {
			return "", err
		}
	}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("failed to get user ID. Status code: %d", resp.StatusCode)
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	var users []UserIDResponse
	err = json.Unmarshal(body, &users)
	if err != nil {
		return "", err
	}

	if len(users) > 0 {
	    provisionerCache.SetBytes(context.Background(),username,[]byte(users[0].ID))
		return users[0].ID, nil
	}

	return "", nil
}
func createUser(api orchestrator.Orchestrator, baseURL, realmName, token, username, email, firstName, lastName string) (string, error) {
	url := fmt.Sprintf("%s/admin/realms/%s/users", baseURL, realmName)

	user := User{
		Username:  username,
		Email:     email,
		FirstName: firstName,
		LastName:  lastName,
		Enabled:   true,
	}

	jsonData, err := json.Marshal(user)
	if err != nil {
		return "", err
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return "", err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")

	apiHttp := api.HTTP()
	
	// Attempt to retrieve an already stored client.
	client, err := apiHttp.GetClient("apiClient")
	if err != nil {
		// Create a new client if one has not already been stored.
		client = &http.Client{Timeout: time.Second * 5}
		err := apiHttp.SetClient("apiClient", client)
		if err != nil {
			return "", err
		}
	}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusCreated {
		return "", fmt.Errorf("failed to create user. Status code: %d", resp.StatusCode)
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	var userIDResponse UserIDResponse
	err = json.Unmarshal(body, &userIDResponse)
	if err != nil {
		return "", err
	}

	return userIDResponse.ID, nil
}
func executeUpdatePasswordAction(api orchestrator.Orchestrator, baseURL, realmName, token, userID string) error {
	url := fmt.Sprintf("%s/admin/realms/%s/users/%s/execute-actions-email", baseURL, realmName, userID)
	data := `["UPDATE_PASSWORD"]`

	req, err := http.NewRequest("PUT", url, bytes.NewBuffer([]byte(data)))
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")

		apiHttp := api.HTTP()
	
	// Attempt to retrieve an already stored client.
	client, err := apiHttp.GetClient("apiClient")
	if err != nil {
		// Create a new client if one has not already been stored.
		client = &http.Client{Timeout: time.Second * 5}
		err := apiHttp.SetClient("apiClient", client)
		if err != nil {
			return err
		}
	}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("failed to execute update password action. Status code: %d", resp.StatusCode)
	}

	return nil
}
func addUserToGroups(api orchestrator.Orchestrator,baseURL string, realmName string, token string, userID string, groupNames []string) error {
	for _, groupName := range groupNames {
		url := fmt.Sprintf("%s/admin/realms/%s/users/%s/groups/%s", baseURL, realmName, userID, groupName)

		req, err := http.NewRequest("PUT", url, nil)
		if err != nil {
			return err
		}
		req.Header.Set("Authorization", "Bearer "+token)
	apiHttp := api.HTTP()
	
	// Attempt to retrieve an already stored client.
	client, err := apiHttp.GetClient("apiClient")
	if err != nil {
		// Create a new client if one has not already been stored.
		client = &http.Client{Timeout: time.Second * 5}
		err := apiHttp.SetClient("apiClient", client)
		if err != nil {
			return fmt.Errorf("failed to create HTTP client: %w", err)
		}
	}
		resp, err := client.Do(req)
		if err != nil {
			return err
		}
		defer resp.Body.Close()

		if resp.StatusCode != http.StatusNoContent {
			return fmt.Errorf("failed to add user to group %s. Status code: %d", groupName, resp.StatusCode)
		}
	}

	return nil
}

func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	var (
		logger  = api.Logger()
	)
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}
	logger.Debug("se", "determining if user is authenticated")

	isKeycloakAuth, err := session.GetString(keycloakConnectorName+".authenticated")
	if err != nil {
		logger.Error("se", "unable to retrieve session value for keycloak auth", "error", err.Error())
	}
	if isKeycloakAuth == "true" {
		return true
	}
    isEntraAuth, err := session.GetString(entraConnectorName+".authenticated")
    if err != nil {
		logger.Error("se", "unable to retrieve session value for entra auth", "error", err.Error())
	}
    if isEntraAuth == "true" {
        provisionerCache,err := api.Cache("/provisioning-users")
        if(err != nil){
            logger.Error("loggedInSE","Unable to get /caep-events cache, events will not be processed!")
        }
        cacheKey,err := session.GetString(entraConnectorName+".preferred_username")
        if(err != nil){
            logger.Error("loggedInSE","No preferred_username claim found on session! Unable to retrieve user caep event queue from cache")
        }
        cachedBytes,err := provisionerCache.GetBytes(context.Background(),cacheKey)
        if(err != nil){
	        logger.Error("loggedInSE","No provisioning record for user:'"+cacheKey+"' found in cache!")
	        _ = provision(api)
	        return true
	    }
        cachedVal := string(cachedBytes)
        if(len(cachedVal) > 0){
        _ = provision(api)
        }
		return true
	}
	logger.Info("se","No session detected. Redirecting user for authentication...")
	return false
}

func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "authenticating user")

	continuityIDP, err := api.IdentityProvider(continuityConnectorName)
	if err != nil {
		logger.Error(
			"se-authenticate", "failed to retrieve Continuity IDP by name.'"+continuityConnectorName+"' not found in config.",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return
	}
	continuityIDP.Login(rw, req)
}
