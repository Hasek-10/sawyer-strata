package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"
	"time"

	"github.com/go-jose/go-jose/v3"
	"github.com/go-jose/go-jose/v3/jwt"
	"github.com/strata-io/service-extension/log"
	"github.com/strata-io/service-extension/orchestrator"
)

type TokenExchangeRequest struct {
	GrantType          string `json:"grant_type"`
	SubjectToken       string `json:"subject_token"`
	SubjectTokenType   string `json:"subject_token_type"`
	RequestedTokenType string `json:"requested_token_type"`
	Scope              string `json:"scope,omitempty"`
}

type TokenExchangeResponse struct {
	AccessToken     string `json:"access_token"`
	TokenType       string `json:"token_type"`
	ExpiresIn       int    `json:"expires_in"`
	IssuedTokenType string `json:"issued_token_type"`
}

func Serve(api orchestrator.Orchestrator) error {
	logger := api.Logger()
	router := api.Router()

	err := router.HandleFunc("/ai-token-exchange", func(w http.ResponseWriter, r *http.Request) {
		logger := api.Logger(log.WithRequest(r))
		logger.Info("step", "0/5", "msg", "Received request", "method", r.Method, "url", r.URL.String(), "headers", r.Header, "form", r.Form)
		r.ParseForm()

		logger.Info("step", "1/5", "msg", "Starting PKCE validation", "client_id", r.FormValue("client_id"), "code_challenge_method", r.FormValue("code_challenge_method"))
		// PKCE validation
		codeVerifier := r.FormValue("code_verifier")
		codeChallenge := r.FormValue("code_challenge")
		codeChallengeMethod := r.FormValue("code_challenge_method")
		if codeVerifier == "" || codeChallenge == "" || codeChallengeMethod == "" {
			logger.Error("step", "1/5 (error)", "msg", "Missing PKCE parameters")
			http.Error(w, "missing PKCE parameters", http.StatusBadRequest)
			return
		}
		if codeChallengeMethod != "S256" {
			logger.Error("step", "1/5 (error)", "msg", "Unsupported code_challenge_method", "method", codeChallengeMethod)
			http.Error(w, "unsupported code_challenge_method", http.StatusBadRequest)
			return
		}
		sha := sha256.New()
		sha.Write([]byte(codeVerifier))
		hash := sha.Sum(nil)
		pkceEncoded := base64.RawURLEncoding.EncodeToString(hash)
		if pkceEncoded != codeChallenge {
			logger.Error("step", "1/5 (error)", "msg", "PKCE validation failed", "computed", pkceEncoded, "expected", codeChallenge)
			http.Error(w, "PKCE validation failed", http.StatusUnauthorized)
			return
		}
		logger.Info("step", "1/5", "msg", "PKCE validation succeeded")

		// 1. Extract agent metadata from request
		clientID := r.FormValue("client_id")
		agentInstanceID := r.FormValue("agent_instance_id")
		agentPurpose := r.FormValue("agent_purpose")
		// ... (other fields as needed)

		// 2. Keycloak provisioning
		metadata := api.Metadata()
		keycloakURL, _ := metadata["KEYCLOAK_URL"].(string) // e.g., https://keycloak.example.com
		realm, _ := metadata["KEYCLOAK_REALM"].(string)
		introspectionURL, _ := metadata["OIDC_INTROSPECTION_URL"].(string)
		scimURL, _ := metadata["SCIM_URL"].(string)
		logger.Info("step", "2/5", "msg", "Using SCIM URL", "scim_url", scimURL)
		logger.Info("step", "3/5", "msg", "Using OIDC introspection URL", "introspection_url", introspectionURL)

		// Acquire admin credentials from secret provider
		secret, err := api.SecretProvider()
		if err != nil {
			logger.Error("msg", "Failed to get secret provider", "err", err.Error())
			http.Error(w, "internal_error", http.StatusInternalServerError)
			return
		}
		adminUser := secret.GetString("KEYCLOAK_ADMIN_USER")
		adminPassword := secret.GetString("KEYCLOAK_ADMIN_PASSWORD")

		// Dynamically acquire admin token
		adminToken, err := getKeycloakAdminToken(keycloakURL, realm, adminUser, adminPassword)
		if err != nil {
			logger.Error("step", "2/5 (error)", "msg", "Failed to acquire Keycloak admin token", "err", err.Error())
			http.Error(w, "internal_error", http.StatusInternalServerError)
			return
		}

		// Check if user exists
		userExists, err := keycloakUserExists(keycloakURL, realm, adminToken, clientID)
		if err != nil {
			logger.Error("step", "2/5 (error)", "msg", "Keycloak user check failed", "err", err.Error())
			http.Error(w, "internal_error", http.StatusInternalServerError)
			return
		}

		if !userExists {
			logger.Info("step", "2/5", "msg", "User does not exist, provisioning via SCIM", "client_id", clientID)
			// Set expiration to now + 5 days
			expiration := time.Now().Add(5 * 24 * time.Hour).Unix()

			// Determine groups based on agent purpose
			groups := []map[string]string{}
			if strings.Contains(strings.ToLower(agentPurpose), "calendar") {
				groups = append(groups, map[string]string{"value": "AI_Calendar_Managers"})
			}
			if strings.Contains(strings.ToLower(agentPurpose), "email") {
				groups = append(groups, map[string]string{"value": "AI_Email_Writers"})
			}

			// Build SCIM user object
			scimUser := map[string]interface{}{
				"userName":    clientID,
				"active":      true,
				"schemas":     []string{"urn:ietf:params:scim:schemas:core:2.0:User"},
				"externalId":  agentInstanceID,
				"displayName": agentPurpose,
				"groups":      groups,
				"urn:ietf:params:scim:schemas:extension:enterprise:2.0:User": map[string]interface{}{
					"agent_registration_expiration": fmt.Sprintf("%d", expiration),
					"agent_purpose":                 agentPurpose,
					"agent_instance_id":             agentInstanceID,
					"client_type":                   "ai_agent",
					"agent_status":                  "active",
					"agent_created_at":              fmt.Sprintf("%d", time.Now().Unix()),
					"agent_last_used":               fmt.Sprintf("%d", time.Now().Unix()),
					"agent_version":                 "1.0",
				},
			}
			body, _ := json.Marshal(scimUser)
			req, _ := http.NewRequest("POST", scimURL, bytes.NewBuffer(body))
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("X-Keycloak-Admin-Token", adminToken)
			resp, err := http.DefaultClient.Do(req)
			respBody, _ := ioutil.ReadAll(resp.Body)
			logger.Info("step", "2a/5", "msg", "SCIM response received", "status", resp.StatusCode, "body", string(respBody))
			if err != nil || (resp.StatusCode != 201 && resp.StatusCode != 200) {
				logger.Error("step", "2/5 (error)", "msg", "SCIM user provisioning failed", "err", err, "status", resp.StatusCode)
				http.Error(w, "scim_provisioning_failed", http.StatusInternalServerError)
				return
			}
			logger.Info("step", "2/5", "msg", "Provisioned new AI agent via SCIM", "client_id", clientID)
		} else {
			logger.Info("step", "2/5", "msg", "User already exists in Keycloak", "client_id", clientID)
		}

		// After Keycloak provisioning
		// 3. Introspect subject_token to get human user info
		subjectToken := r.FormValue("subject_token")
		clientSecret := r.FormValue("client_secret")
		var humanSub, humanEmail string
		if introspectionURL != "" && subjectToken != "" {
			introspectReq, _ := http.NewRequest("POST", introspectionURL, strings.NewReader("token="+subjectToken))
			introspectReq.Header.Set("Content-Type", "application/x-www-form-urlencoded")
			if clientID != "" && clientSecret != "" {
				introspectReq.SetBasicAuth(clientID, clientSecret)
			}
			resp, err := http.DefaultClient.Do(introspectReq)
			if err != nil {
				logger.Error("step", "3/5 (error)", "msg", "OIDC introspection failed", "err", err)
				http.Error(w, "introspection_failed", http.StatusUnauthorized)
				return
			}
			defer resp.Body.Close()
			var introspect map[string]interface{}
			if err := json.NewDecoder(resp.Body).Decode(&introspect); err != nil {
				logger.Error("step", "3/5 (error)", "msg", "Failed to decode introspection response", "err", err)
				http.Error(w, "introspection_decode_failed", http.StatusInternalServerError)
				return
			}
			logger.Info("step", "3a/5", "msg", "Full OIDC introspection response", "introspect", introspect)
			if active, ok := introspect["active"].(bool); !ok || !active {
				http.Error(w, "subject_token_inactive", http.StatusUnauthorized)
				return
			}
			if sub, ok := introspect["sub"].(string); ok {
				humanSub = sub
			}
			if email, ok := introspect["email"].(string); ok {
				humanEmail = email
			}
			logger.Info("step", "3/5", "msg", "OIDC introspection succeeded", "sub", humanSub, "email", humanEmail)
		}

		// 4. Query Keycloak for agent's attributes and groups
		agentAttrs, agentGroups, err := getKeycloakUserAttrsAndGroups(keycloakURL, realm, adminToken, clientID)
		if err != nil {
			logger.Error("step", "4/5 (error)", "msg", "Failed to get agent attributes/groups", "err", err)
			http.Error(w, "keycloak_query_failed", http.StatusInternalServerError)
			return
		}

		// Scope enforcement based on groups
		groupScopeMap := map[string][]string{
			"AI_Calendar_Managers": {"delegate_calendar"},
			"AI_Email_Writers":     {"delegate_email"},
			// Add more group-to-scope mappings as needed
		}
		allowedScopesSet := map[string]struct{}{}
		for _, group := range agentGroups {
			if scopes, ok := groupScopeMap[group]; ok {
				for _, s := range scopes {
					allowedScopesSet[s] = struct{}{}
				}
			}
		}
		requestedScopes := strings.Fields(r.FormValue("scope"))
		finalScopes := []string{}
		for _, s := range requestedScopes {
			if _, ok := allowedScopesSet[s]; ok {
				finalScopes = append(finalScopes, s)
			}
		}
		if len(finalScopes) == 0 {
			logger.Error("step", "4/5 (error)", "msg", "No allowed scopes for agent", "requested_scopes", r.FormValue("scope"), "agent_groups", agentGroups)
			http.Error(w, "no allowed scopes for agent", http.StatusForbidden)
			return
		}
		finalScopeStr := strings.Join(finalScopes, " ")
		logger.Info("step", "4/5", "msg", "Allowed scopes determined", "allowed_scopes", finalScopeStr)

		// 5. Build token claims
		now := time.Now().Unix()
		exp := now + 3600 // 1 hour expiry
		regExp := agentAttrs["agent_registration_expiration"]
		if regExp == "" {
			regExp = fmt.Sprintf("%d", now+5*24*3600)
		}

		// Get orchestrator URL and audience from metadata
		orchestratorURL, _ := metadata["ORCHESTRATOR_URL"].(string)
		if orchestratorURL == "" {
			logger.Error("step", "5/5 (error)", "msg", "ORCHESTRATOR_URL not set in metadata")
			http.Error(w, "orchestrator_url_missing", http.StatusInternalServerError)
			return
		}

		// Parse audience from metadata - can be comma-separated list
		audienceStr, _ := metadata["TOKEN_AUDIENCE"].(string)
		if audienceStr == "" {
			logger.Error("step", "5/5 (error)", "msg", "TOKEN_AUDIENCE not set in metadata")
			http.Error(w, "token_audience_missing", http.StatusInternalServerError)
			return
		}
		audience := strings.Split(audienceStr, ",")

		claims := map[string]interface{}{
			"iss":                           orchestratorURL,
			"sub":                           humanSub,
			"aud":                           audience,
			"exp":                           exp,
			"iat":                           now,
			"scope":                         finalScopeStr,
			"client_id":                     clientID,
			"token_type":                    "Bearer",
			"actor":                         clientID,
			"client_type":                   agentAttrs["client_type"],
			"agent_instance_id":             agentAttrs["agent_instance_id"],
			"agent_purpose":                 agentAttrs["agent_purpose"],
			"delegation_type":               "ai_delegation",
			"delegated_by":                  humanSub,
			"delegated_at":                  now,
			"agent_registration_expiration": regExp,
			"groups":                        agentGroups,
		}
		if humanEmail != "" {
			claims["email"] = humanEmail
		}

		// Sign the JWT using go-jose
		jwtKey := secret.GetString("JWT_SIGNING_KEY")
		if jwtKey == "" {
			logger.Error("step", "5/5 (error)", "msg", "JWT signing key not set in secret provider")
			http.Error(w, "jwt_signing_key_missing", http.StatusInternalServerError)
			return
		}
		// Create signer
		signer, err := jose.NewSigner(jose.SigningKey{Algorithm: jose.HS256, Key: []byte(jwtKey)}, (&jose.SignerOptions{}).WithType("JWT"))
		if err != nil {
			logger.Error("step", "5/5 (error)", "msg", "Failed to create JWT signer", "err", err)
			http.Error(w, "jwt_signing_failed", http.StatusInternalServerError)
			return
		}
		builder := jwt.Signed(signer).Claims(claims)
		signedToken, err := builder.CompactSerialize()
		if err != nil {
			logger.Error("step", "5/5 (error)", "msg", "Failed to sign JWT", "err", err)
			http.Error(w, "jwt_signing_failed", http.StatusInternalServerError)
			return
		}

		logger.Info("step", "5/5", "msg", "Token exchange completed successfully", "access_token", signedToken)
		logger.Info("step", "5a/5", "msg", "Sending HTTP response", "status", http.StatusOK, "body", map[string]interface{}{"access_token": signedToken, "token_type": "Bearer", "expires_in": 3600})

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"access_token": signedToken,
			"token_type":   "Bearer",
			"expires_in":   3600,
		})
	})
	if err != nil {
		return fmt.Errorf("failed to register /ai-token-exchange: %w", err)
	}
	logger.Info("msg", "Registered /ai-token-exchange endpoint")
	return nil
}

// Helper: Check if Keycloak user exists
func keycloakUserExists(baseURL, realm, adminToken, username string) (bool, error) {
	url := fmt.Sprintf("%s/admin/realms/%s/users?username=%s", baseURL, realm, username)
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Authorization", "Bearer "+adminToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	return strings.Contains(string(body), username), nil
}

// Helper: Acquire Keycloak admin token using client credentials
func getKeycloakAdminToken(baseURL, realm, username, password string) (string, error) {
	tokenURL := fmt.Sprintf("%s/realms/%s/protocol/openid-connect/token", baseURL, realm)
	data := "grant_type=password&client_id=admin-cli&username=" + username + "&password=" + password
	req, _ := http.NewRequest("POST", tokenURL, strings.NewReader(data))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		b, _ := ioutil.ReadAll(resp.Body)
		return "", fmt.Errorf("failed to get admin token: %s", string(b))
	}
	var result map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", err
	}
	token, ok := result["access_token"].(string)
	if !ok {
		return "", fmt.Errorf("no access_token in response")
	}
	return token, nil
}

// Helper: Query Keycloak for user attributes and groups
func getKeycloakUserAttrsAndGroups(baseURL, realm, adminToken, username string) (map[string]string, []string, error) {
	url := fmt.Sprintf("%s/admin/realms/%s/users?username=%s", baseURL, realm, username)
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Authorization", "Bearer "+adminToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, nil, err
	}
	defer resp.Body.Close()
	var users []map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&users); err != nil || len(users) == 0 {
		return nil, nil, fmt.Errorf("user not found or decode error")
	}
	user := users[0]
	attrs := map[string]string{}
	if m, ok := user["attributes"].(map[string]interface{}); ok {
		for k, v := range m {
			if arr, ok := v.([]interface{}); ok && len(arr) > 0 {
				attrs[k] = fmt.Sprintf("%v", arr[0])
			} else if s, ok := v.(string); ok {
				attrs[k] = s
			}
		}
	}
	// Get groups
	groupsURL := fmt.Sprintf("%s/admin/realms/%s/users/%s/groups", baseURL, realm, user["id"])
	greq, _ := http.NewRequest("GET", groupsURL, nil)
	greq.Header.Set("Authorization", "Bearer "+adminToken)
	gresp, err := http.DefaultClient.Do(greq)
	if err != nil {
		return attrs, nil, err
	}
	defer gresp.Body.Close()
	var groups []map[string]interface{}
	if err := json.NewDecoder(gresp.Body).Decode(&groups); err != nil {
		return attrs, nil, err
	}
	groupNames := []string{}
	for _, g := range groups {
		if name, ok := g["name"].(string); ok {
			groupNames = append(groupNames, name)
		}
	}
	return attrs, groupNames, nil
}
