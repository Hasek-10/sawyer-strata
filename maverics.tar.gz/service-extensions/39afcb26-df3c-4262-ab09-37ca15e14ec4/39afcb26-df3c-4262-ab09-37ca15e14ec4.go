package main
import (
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

// Note: To use this service extension with a SAML user flow, the signature must include a response writer.
// Ex. func BuildTokenClaims(api orchestrator.Orchestrator, rw, http.ResponseWriter, _ *http.Request) (map[string]any, error)
func BuildTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return nil, err
	}
	em, _ := session.GetString("Okta-OIDC-Fastpass-Mavs12.email")
	if(em == ""){
	    em,_ = session.GetString("LDAP_Authentication.email")
	}
	
	fn, _ := session.GetString("Okta-OIDC-Fastpass-Mavs12.firstname")
	if(fn == ""){
	    fn,_ = session.GetString("LDAP_Authentication.firstname")
	}
	ln, _ := session.GetString("Okta-OIDC-Fastpass-Mavs12.lastname")
	if(ln == ""){
	    ln,_ = session.GetString("LDAP_Authentication.lastname")
	}
	return map[string]any{
		"SM_USER": em,
		"firstName": fn,
		"lastName": ln,
	}, nil
}

