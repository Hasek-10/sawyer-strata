package main
import (
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

// Note: To use this service extension with a SAML user flow, the signature must include a response writer.
// Ex. func BuildTokenClaims(api orchestrator.Orchestrator, rw, http.ResponseWriter, _ *http.Request) (map[string]any, error)
func BuildTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	session, err := api.Session()
	if err != nil {
		logger.Error("se BuildTokenClaims", "unable to retrieve session", "error", err.Error())
		return nil, err
	}
	em, _ := session.GetString("generic.email")
	logger.Debug("se BuildTokenClaims", "Got 'Okta-OIDC-Fastpass-Mav12.email' from Okta as: "+em, "Debug")
	if(em == ""){
	    em,_ = session.GetString("LDAP_Authentication.email")
	    logger.Debug("se BuildTokenClaims", "Got 'LDAP_Authentication.email' from AD as: "+em, "Debug")
	}
	
	fn, _ := session.GetString("generic.firstname")
	logger.Debug("se BuildTokenClaims", "Got 'Okta-OIDC-Fastpass-Mav12.firstname' from Okta as: "+fn, "Debug")

	if(fn == ""){
	    fn,_ = session.GetString("LDAP_Authentication.firstname")
	    logger.Debug("se BuildTokenClaims", "Got 'LDAP_Authentication.firstname' from AD as: "+fn, "Debug")
	}
	ln, _ := session.GetString("generic.lastname")
	logger.Debug("se BuildTokenClaims", "Got 'Okta-OIDC-Fastpass-Mav12.lastname' from Okta as: "+ln, "Debug")
	if(ln == ""){
	    ln,_ = session.GetString("LDAP_Authentication.lastname")
	    logger.Debug("se BuildTokenClaims", "Got 'LDAP_Authentication.lastname' from AD as: "+ln, "Debug")
	}
	return map[string]any{
		"SM_USER": em,
		"given_name": fn,
		"family_name": ln,
		"firstname": fn,
		"name": fn+ln,
		"email": em,
	}, nil
}

