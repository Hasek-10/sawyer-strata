package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
)

const (
	oktaTokenURL = "https://strata-okta-partner.okta.com/oauth2/default/v1/token"
	//PingOne does not support the ROPC flow.
	pingFederateTokenURL = "https://auth.pingone.com/c874de1f-2e87-4cc5-b80f-f0c965d508c7/as/token"
	//pingFederateTokenURL      = "https://{insert pingfed domain here}/as/token.oauth2"
)

var clientIDProviderMap = map[string]string{
	"0oag5k0vg9Ct4sEvZ697": "okta",
	"oktaClientID2": "okta",
	"pingClientID1": "ping",
	"pingClientID2": "ping",
}

// Double check incoming request structure - Okta seems to require a scope be specified for ROPC flow. https://developer.okta.com/docs/reference/api/oidc/#token
type OAuthRequest struct {
	ClientID     string `json:"client_id"`
	ClientSecret string `json:"client_secret"`
	Username     string `json:"username"`
	Password     string `json:"password"`
	GrantType    string `json:"grant_type"`
	Scope     string `json:"scope,omitempty"`
}

type OAuthResponse struct {
	AccessToken string `json:"access_token"`
	IDToken     string `json:"id_token,omitempty"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
	ClientID  string `json:"client_id,omitempty"`
}

//This may no longer be needed
type IntrospectResponse struct {
	AccessToken json.RawMessage `json:"access_token"`
	//Since this is pure OAuth and we are just passing tokens, "scope" should be empty or omitted, probably good to test to verify response shape before removing this.
	Scope     string `json:"scope,omitempty"`
	ClientID  string `json:"client_id,omitempty"`
	TokenType string `json:"token_type,omitempty"`
	ExpiresIn int    `json:"expires_in,omitempty"`
}

func Serve(api orchestrator.Orchestrator) error {
	router := api.Router()
	err := router.HandleFunc("/as/token.oauth2", handleOAuth(api))
	if err != nil {
		return fmt.Errorf("failed to handle route: %w", err)
	}
	return nil
}

func handleOAuth(api orchestrator.Orchestrator) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		logger := api.Logger()
		logger.Info("se", "Received OAuth request")

		var oauthReq OAuthRequest
		body, err := ioutil.ReadAll(r.Body)
		if err != nil {
			http.Error(w, "Failed to read request body", http.StatusBadRequest)
			return
		}
		//The okta token endpoint needs a digest of the username+password for basic auth.
		basicAuth := r.Header.Get("Authentication")
		err = json.Unmarshal(body, &oauthReq)
		if err != nil {
			logger.Error("se", "Failed to parse JSON from request body - dumping request body")
			http.Error(w, "Invalid JSON format", http.StatusBadRequest)
			logger.Error("se", body) //Remove this after testing to avoid logging secrets
			return
		}

		identityProvider, ok := clientIDProviderMap[oauthReq.ClientID]
		if !ok {
			http.Error(w, "Invalid client_id", http.StatusBadRequest)
			return
		}
		if len(oauthReq.Password) == 0 {
			logger.Info("se", "Password is empty!")
		}
		if len(oauthReq.Username) == 0 {
			logger.Info("se", "Username is empty!")
		}
		if len(oauthReq.Scope) == 0 {
			logger.Info("se", "Scope is empty!")
		}
		var tokenURL string

		if identityProvider == "okta" {
			logger.Info("se", "Sending OAuth request to Okta")
			tokenURL = oktaTokenURL
		} else if identityProvider == "ping" {
			logger.Info("se", "Sending OAuth request to Ping")
			tokenURL = pingFederateTokenURL
		} else {
			http.Error(w, "Unsupported IdentityProvider", http.StatusBadRequest)
			return
		}

		logger.Info("se", "OAuth request fields - omitting password and client secret:")
		logger.Info("se", "Username:"+oauthReq.Username)
		logger.Info("se", "ClientID:"+oauthReq.ClientID)
		//We may wish to log the full response here for initial testing
		oAuthResponse, err := requestToken(tokenURL, oauthReq.Username, oauthReq.Password, oauthReq.ClientID, oauthReq.ClientSecret, oauthReq.GrantType, oauthReq.Scope,basicAuth)
		if err != nil {
			http.Error(w, "Failed to obtain token: "+err.Error(), http.StatusInternalServerError)
			return
		}
		jsonResponse(w, oAuthResponse)

	}
}

func requestToken(tokenURL, username, password, clientID, clientSecret string, grantType string, scope string, basicAuth string) (*OAuthResponse, error) {
	data := "grant_type=" + grantType +"&username=" + username + "&password=" + password + "&client_id=" + clientID + "&client_secret=" + clientSecret
	if (len(scope) > 0){
		data += "&scope=" + scope
	}
	
	req, err := http.NewRequest("POST", tokenURL, strings.NewReader(data))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	if len(basicAuth) > 0 {
		req.Header.Set("Authorization", basicAuth)
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("token request failed with status: %d", resp.StatusCode)
	}

	var oAuthResponse OAuthResponse
	err = json.NewDecoder(resp.Body).Decode(&oAuthResponse)
	if err != nil {
		return nil, err
	}

	return &oAuthResponse, nil
}

func jsonResponse(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}
