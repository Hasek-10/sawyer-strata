package main
import (
	"net/http"
    "time"
    "context"
	"io/ioutil"
    "errors"
    "fmt"
    "encoding/json"
    "bytes"
	"github.com/strata-io/service-extension/orchestrator"
)

// Note: To use this service extension with a SAML user flow, the signature must include a response writer.
// Ex. func BuildTokenClaims(api orchestrator.Orchestrator, rw, http.ResponseWriter, _ *http.Request) (map[string]any, error)
func BuildTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return nil, err
	}
	roles, _ := session.GetString("okta.roles")
	return map[string]any{
		"scope": roles,
	}, nil
}

const (
    /*Keycloak JIT provisioning constants*/
	baseURL   = "https://keycloak.stratademo.io/"
	realmName = "master"
	//Get these off the session...

	// Get groups from the microsoft graph api...
	adminUsernameSecret = "Keycloak-admin-username"
	adminPasswordSecret = "Keycloak-admin-password"
	clientIDSecret = "Keycloak-admin-client"
	
	/*Maveric Constants*/
	entraConnectorName = "Entra_Maverics9"
	keycloakConnectorName = "Keycloak"
	continuityConnectorName = "Entra_Keycloak_DDIL_v2"
	graphApiConnectorName = "Entra_Maverics9_Graph"
)

type TokenResponse struct {
	AccessToken string `json:"access_token"`
	TokenType string `json:"token_type"`
	NotBeforePolicy int `json:"not-before-policy"`
	SessionState string `json:"session_state"`
	Scope string `json:"scope"`

}

type User struct {
	Username  string `json:"username"`
	Email     string `json:"email"`
	FirstName string `json:"firstName"`
	LastName  string `json:"lastName"`
	Enabled   bool   `json:"enabled"`
}

type UserIDResponse struct {
	ID string `json:"id"`
}

func provision(api orchestrator.Orchestrator) error{
    logger := api.Logger()
    secrets, err := api.SecretProvider()
    session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return err
	}
    username,err := session.GetString(entraConnectorName+".preferred_username")
    email,err := session.GetString(entraConnectorName+".email")
    firstName,err := session.GetString(entraConnectorName+".given_name")
    lastName,err := session.GetString(entraConnectorName+".family_username")
    //store the admin bearer token here
 //   tokenCache, err := api.Cache("/provisioning-token")
    //put provisioned usernames here to minimize round trips
    

	if err != nil {
		logger.Error(
			"se", "failed to retrieve secret provider",
			"error", err.Error(),
		)
		return errors.New("failed to retrieve secret provider")
	}
	adminUsername := secrets.GetString(adminUsernameSecret)
	adminPassword := secrets.GetString(adminPasswordSecret)
	clientID := secrets.GetString(clientIDSecret)
	// Obtain an admin access token TODO: Maintain token in orchestrator cache 
	token, err := getAdminToken(api,baseURL, realmName, adminUsername, adminPassword, clientID)
	if err != nil {
		logger.Error("se-provisioner","Unable to retrieve a token for secondary user provisioning", "se-provisioner-underlying", err)
		return err
	}
    logger.Info("se-provisioner","AT="+token)
	// Check if user exists 
	userID, err := getUserID(api,baseURL, realmName, token, username)
	if err != nil {
		logger.Error("se-provisioner","Unable to determine if user is provisioned: "+username, "se-provisioner-underlying", err)
		return err
	}

	if userID != "" {
		logger.Info("se-provisioner","User already exists: "+username)
	} else {
		// Create the user
				logger.Info("se-provisioner", "Starting provisioning for "+username)

		userID, err = createUser(api, baseURL, realmName, token, username, email, firstName, lastName)
		if err != nil {
				logger.Error("se-provisioner",err)
			return err
		}
		logger.Info("se-provisioner", "Provisioned a new user with ID: "+userID)
		// Force password reset on first login
	/*	logger.Info("se-provisioner","Resetting password on: "+userID)
		err = executeUpdatePasswordAction(api,baseURL, realmName, token, userID)
		if err != nil {
			logger.Error("se-provisioner",err)
			return err
		} */
    groups := []string{"test-group2","test-Entra-Provisioning"}
    entraGraphAttrProvider, err := api.AttributeProvider(graphApiConnectorName)
	if err != nil {
		logger.Error(
			"se", "failed to retrieve Graph API attribute provider",
			"error", err.Error(),
		)
		return err
	}

	attrs, err := entraGraphAttrProvider.Query(
		username,
		[]string{"memberOf"},
	)
	if err != nil {
		logger.Error(
			"se", "failed to query Graph API for groups",
			"error", err.Error(),
		)
		//http.Error(
		//	rw,
		//	http.StatusText(http.StatusInternalServerError),
		//	http.StatusInternalServerError,
		//)
		return err
	}
	graphGroups := attrs[graphApiConnectorName+".memberOf"]
	logger.Info("se-group-provision","Retrieved groups: "+graphGroups)
		// Add the user to groups
		err = addUserToGroups(api, baseURL, realmName, token, userID, groups)
		if err != nil {
			logger.Error("se-provisioner",err)
			return err
		}



		fmt.Println("User created and password reset action executed successfully.")
	}
	return nil
}
func getAdminToken(api orchestrator.Orchestrator,baseURL, realmName, adminUsername, adminPassword, clientID string) (string, error) {
	url := fmt.Sprintf("%s/realms/%s/protocol/openid-connect/token", baseURL, realmName)
	data := fmt.Sprintf("username=%s&password=%s&client_id=%s&grant_type=password", adminUsername, adminPassword, clientID)
    logger := api.Logger()
	req, err := http.NewRequest("POST", url, bytes.NewBuffer([]byte(data)))
	if err != nil {
	    logger.Error("se-provisioner", "Unable to generate HTTP request")
		return "", err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	apiHttp := api.HTTP()
	
	// Attempt to retrieve an already stored client.
	client, err := apiHttp.GetClient("apiClient")
	if err != nil {
		// Create a new client if one has not already been stored.
		client = &http.Client{Timeout: time.Second * 5}
		err := apiHttp.SetClient("apiClient", client)
		if err != nil {
		    logger.Error("se-provisioner", "Unable to create HTTP client for requesting admin token!")
			return "", err
		}
	}
	resp, err := client.Do(req)
	if err != nil {
	    logger.Error("se-provisioner", "Admin Token Request failed")
		return "", err
	}
	defer resp.Body.Close()


	// Log the response body
//	logger.Info("se-provisioner-RESPONSE", body)
	

	var tokenResponse TokenResponse
	err = json.NewDecoder(resp.Body).Decode(&tokenResponse)
	if err != nil {
	    logger.Error("se-underlying-error", err)
	    logger.Error("se-provisioner", "Failed to decode admin token response")
	    return "", err
	}
    logger.Info("se-provisioner", "TESTING - AT="+tokenResponse.AccessToken)
	return tokenResponse.AccessToken, nil
}

func getUserID(api orchestrator.Orchestrator,baseURL, realmName, token, username string) (string, error) {
    logger := api.Logger()
	url := fmt.Sprintf("%s/admin/realms/%s/users?username=%s", baseURL, realmName, username)
    provisionerCache, err:=api.Cache("/provisioning-users")
    cachedBytes,err := provisionerCache.GetBytes(context.Background(), username)
    if(err != nil){
        logger.Info("User:'"+username+"' not found in cache. Checking secondary directory.")
    }
    if(len(cachedBytes) > 0){
        logger.Info("User:'"+username+"' found in cache. Returning early")
        return string(cachedBytes),nil
    }
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("Authorization", "Bearer "+token)

	apiHttp := api.HTTP()
	logger.Info("se-provisioner","Checking for user at: "+url)
	// Attempt to retrieve an already stored client.
	client, err := apiHttp.GetClient("apiClient")
	if err != nil {
		// Create a new client if one has not already been stored.
		client = &http.Client{Timeout: time.Second * 5}
		err := apiHttp.SetClient("apiClient", client)
		if err != nil {
			return "", err
		}
	}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("failed to get user ID. Status code: %d", resp.StatusCode)
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

    logger.Info("se-debug","Raw User Check Response: "+string(body))
	var users []UserIDResponse
//		var tokenResponse TokenResponse
//	err = json.NewDecoder(resp.Body).Decode(&tokenResponse)
	err = json.Unmarshal(body, &users)
	if err != nil {
		return "", nil
	}

	if len(users) > 0 {
	    provisionerCache.SetBytes(context.Background(),username,[]byte(users[0].ID))
		return users[0].ID, nil
	}

	return "", nil
}
func createUser(api orchestrator.Orchestrator, baseURL, realmName, token, username, email, firstName, lastName string) (string, error) {
	url := fmt.Sprintf("%s/admin/realms/%s/users", baseURL, realmName)

	user := User{
		Username:  username,
		Email:     email,
		FirstName: firstName,
		LastName:  lastName,
		Enabled:   true,
	}

	jsonData, err := json.Marshal(user)
	if err != nil {
		return "", err
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return "", err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")

	apiHttp := api.HTTP()
	
	// Attempt to retrieve an already stored client.
	client, err := apiHttp.GetClient("apiClient")
	if err != nil {
		// Create a new client if one has not already been stored.
		client = &http.Client{Timeout: time.Second * 5}
		err := apiHttp.SetClient("apiClient", client)
		if err != nil {
			return "", err
		}
	}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusCreated {
		return "", fmt.Errorf("failed to create user. Status code: %d", resp.StatusCode)
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	var userIDResponse UserIDResponse
	err = json.Unmarshal(body, &userIDResponse)
	if err != nil {
		return "", err
	}

	return userIDResponse.ID, nil
}