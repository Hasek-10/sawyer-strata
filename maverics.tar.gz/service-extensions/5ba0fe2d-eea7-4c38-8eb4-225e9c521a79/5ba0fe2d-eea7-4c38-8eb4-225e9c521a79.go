package main

import (
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
)

func Serve(api orchestrator.Orchestrator) error {
	var (
		logger = api.Logger()
		router = api.Router()
	)

	logger.Info("se", "exposing custom API")

	_ = router.HandleFunc("/getasset", func(rw http.ResponseWriter, req *http.Request) {
	    query := req.URL.Query()
		assetName := query.Get("asset")
		s := strings.Split(assetName, ".")
		if(len(s) == 0 || len(s) == 1){
			http.Error(rw, "Missing image file type on asset name - eg .jpg .png", http.StatusNotFound)
            return
		}
		//os.Open()
		assets := api.ServiceExtensionAssets()
        // ReadFile returns the file contents as a []byte.
        a, err := assets.ReadFile(assetName)
		//imageFile, err := os.Open("path/to/your/image.jpg") // Replace with the actual path
        if err != nil {
            http.Error(rw, "Image not found", http.StatusNotFound)
            return
        }
        
        //defer imageFile.Close()

        // Set the content type header
        rw.Header().Set("Content-Type", "image/"+s[1]) // Adjust content type as needed

        // Copy the image data to the response writer
        // io.Copy(rw, imageFile)
        //http.ServeFile(rw, req,imageFile)
		rw.Write(a)
	})

	return nil
}