package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/strata-io/service-extension/log"
	"github.com/strata-io/service-extension/orchestrator"
)

func Serve(api orchestrator.Orchestrator) error {
	logger := api.Logger()
	router := api.Router()

	err := router.HandleFunc("/scim/v2/Users", func(w http.ResponseWriter, r *http.Request) {
		logger := api.Logger(log.WithRequest(r))
		metadata := api.Metadata()
		keycloakURL, _ := metadata["KEYCLOAK_URL"].(string)
		realm, _ := metadata["KEYCLOAK_REALM"].(string)

		// Get admin token from request header
		adminToken := r.Header.Get("X-Keycloak-Admin-Token")
		if adminToken == "" {
			logger.Error("msg", "Missing Keycloak admin token in request header")
			http.Error(w, "missing_admin_token", http.StatusUnauthorized)
			return
		}

		logger.Info("step", "0/5", "msg", "Received SCIM request", "method", r.Method, "url", r.URL.String(), "headers", r.Header, "query", r.URL.Query())
		if r.Method == http.MethodGet {
			logger.Info("step", "2/5", "msg", "Processing SCIM GET request", "filter", r.URL.Query().Get("filter"))
			// SCIM GET /scim/v2/Users?filter=userName eq "foo"
			filter := r.URL.Query().Get("filter")
			if !strings.HasPrefix(filter, "userName eq ") {
				http.Error(w, "unsupported filter", http.StatusBadRequest)
				return
			}
			userName := strings.Trim(strings.TrimPrefix(filter, "userName eq "), "\"")
			user, groups, err := getKeycloakUserAndGroups(keycloakURL, realm, adminToken, userName)
			if err != nil {
				logger.Error("step", "3/5 (error)", "msg", "Keycloak user fetch failed", "err", err.Error())
				http.Error(w, "user_not_found", http.StatusNotFound)
				return
			}
			resp := map[string]interface{}{
				"schemas":     []string{"urn:ietf:params:scim:schemas:core:2.0:User"},
				"id":          user["username"],
				"userName":    user["username"],
				"displayName": user["attributes"].(map[string]interface{})["agent_purpose"],
				"externalId":  user["attributes"].(map[string]interface{})["agent_instance_id"],
				"active":      user["enabled"],
				"groups":      groups,
			}
			w.Header().Set("Content-Type", "application/scim+json")
			json.NewEncoder(w).Encode(map[string]interface{}{
				"Resources":    []interface{}{resp},
				"totalResults": 1,
				"itemsPerPage": 1,
				"startIndex":   1,
			})
			logger.Info("step", "4/5", "msg", "Fetched user and groups from Keycloak", "user", user, "groups", groups)
			logger.Info("step", "5a/5", "msg", "SCIM GET response sent", "status", http.StatusOK, "response", resp)
			return
		}

		if r.Method == http.MethodPost {
			body, err := io.ReadAll(r.Body)
			logger.Info("step", "2/5", "msg", "Processing SCIM POST request", "body", string(body))
			if err != nil {
				http.Error(w, "Invalid body", http.StatusBadRequest)
				return
			}
			var scimUser map[string]interface{}
			if err := json.Unmarshal(body, &scimUser); err != nil {
				http.Error(w, "Invalid JSON", http.StatusBadRequest)
				return
			}

			// Extract fields from SCIM user
			userName, _ := scimUser["userName"].(string)
			displayName, _ := scimUser["displayName"].(string)
			externalId, _ := scimUser["externalId"].(string)
			active, _ := scimUser["active"].(bool)
			enterpriseExt, _ := scimUser["urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"].(map[string]interface{})
			expStr, _ := enterpriseExt["agent_registration_expiration"].(string)
			var expiration int64
			fmt.Sscanf(expStr, "%d", &expiration)

			// Extract required agent attributes from enterprise extension
			agentPurpose, _ := enterpriseExt["agent_purpose"].(string)
			agentInstanceID, _ := enterpriseExt["agent_instance_id"].(string)

			// Group provisioning support
			groupObjs, _ := scimUser["groups"].([]interface{})
			groupNames := []string{}
			for _, g := range groupObjs {
				if gm, ok := g.(map[string]interface{}); ok {
					if name, ok := gm["value"].(string); ok {
						groupNames = append(groupNames, name)
					}
				}
			}
			logger.Info("step", "3/5", "msg", "Extracted group names for provisioning", "groups", groupNames)

			// Provision user to Keycloak
			err = createKeycloakUserWithGroups(keycloakURL, realm, adminToken, userName, agentInstanceID, agentPurpose, expiration, groupNames)
			if err != nil {
				logger.Error("step", "4/5 (error)", "msg", "Keycloak user creation failed", "err", err.Error())
				http.Error(w, "keycloak_user_creation_failed", http.StatusInternalServerError)
				return
			}
			logger.Info("step", "4a/5", "msg", "User and groups provisioned in Keycloak", "userName", userName, "groups", groupNames)

			// Build SCIM response
			resp := map[string]interface{}{
				"schemas":     []string{"urn:ietf:params:scim:schemas:core:2.0:User"},
				"id":          userName,
				"userName":    userName,
				"displayName": displayName,
				"externalId":  externalId,
				"active":      active,
				"groups":      groupNames,
			}
			w.Header().Set("Content-Type", "application/scim+json")
			w.WriteHeader(http.StatusCreated)
			json.NewEncoder(w).Encode(resp)
			logger.Info("step", "5a/5", "msg", "SCIM POST response sent", "status", http.StatusCreated, "response", resp)
			return
		}

		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	})
	if err != nil {
		return fmt.Errorf("failed to register /scim/v2/Users: %w", err)
	}
	logger.Info("msg", "Registered /scim/v2/Users SCIM endpoint")
	return nil
}

// Helper: Create Keycloak user with group assignment
func createKeycloakUserWithGroups(baseURL, realm, adminToken, clientID, agentInstanceID, agentPurpose string, expiration int64, groups []string) error {
	// Create user
	url := fmt.Sprintf("%s/admin/realms/%s/users", baseURL, realm)
	user := map[string]interface{}{
		"username": clientID,
		"enabled":  true,
		"attributes": map[string]interface{}{
			"client_id":                     []string{clientID},
			"client_type":                   []string{"ai_agent"},
			"agent_purpose":                 []string{agentPurpose},
			"agent_instance_id":             []string{agentInstanceID},
			"agent_registration_expiration": []string{fmt.Sprintf("%d", expiration)},
			"agent_status":                  []string{"active"},
			"agent_created_at":              []string{fmt.Sprintf("%d", time.Now().Unix())},
			"agent_last_used":               []string{fmt.Sprintf("%d", time.Now().Unix())},
			"agent_version":                 []string{"1.0"},
			"agent_capabilities":            []string{strings.Join(groups, ",")},
		},
	}

	// Extract additional attributes from enterprise extension if available
	if enterpriseExt, ok := user["attributes"].(map[string]interface{}); ok {
		if clientType, ok := enterpriseExt["client_type"].(string); ok {
			user["attributes"].(map[string]interface{})["client_type"] = []string{clientType}
		}
		if agentStatus, ok := enterpriseExt["agent_status"].(string); ok {
			user["attributes"].(map[string]interface{})["agent_status"] = []string{agentStatus}
		}
		if agentCreatedAt, ok := enterpriseExt["agent_created_at"].(string); ok {
			user["attributes"].(map[string]interface{})["agent_created_at"] = []string{agentCreatedAt}
		}
		if agentLastUsed, ok := enterpriseExt["agent_last_used"].(string); ok {
			user["attributes"].(map[string]interface{})["agent_last_used"] = []string{agentLastUsed}
		}
		if agentVersion, ok := enterpriseExt["agent_version"].(string); ok {
			user["attributes"].(map[string]interface{})["agent_version"] = []string{agentVersion}
		}
	}

	body, _ := json.Marshal(user)
	req, _ := http.NewRequest("POST", url, bytes.NewBuffer(body))
	req.Header.Set("Authorization", "Bearer "+adminToken)
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 201 && resp.StatusCode != 204 {
		b, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("Keycloak user creation failed: %s", string(b))
	}
	// Get user ID
	userID, err := getKeycloakUserID(baseURL, realm, adminToken, clientID)
	if err != nil {
		return err
	}
	// Assign groups
	for _, group := range groups {
		groupID, err := getKeycloakGroupID(baseURL, realm, adminToken, group)
		if err != nil {
			return fmt.Errorf("failed to get group ID for %s: %w", group, err)
		}
		groupURL := fmt.Sprintf("%s/admin/realms/%s/users/%s/groups/%s", baseURL, realm, userID, groupID)
		greq, _ := http.NewRequest("PUT", groupURL, nil)
		greq.Header.Set("Authorization", "Bearer "+adminToken)
		gresp, err := http.DefaultClient.Do(greq)
		if err != nil || (gresp.StatusCode != 204 && gresp.StatusCode != 201) {
			return fmt.Errorf("failed to assign group %s to user: %v", group, err)
		}
	}
	return nil
}

// Helper: Get Keycloak user and groups by username
func getKeycloakUserAndGroups(baseURL, realm, adminToken, username string) (map[string]interface{}, []string, error) {
	url := fmt.Sprintf("%s/admin/realms/%s/users?username=%s", baseURL, realm, username)
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Authorization", "Bearer "+adminToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, nil, err
	}
	defer resp.Body.Close()
	var users []map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&users); err != nil || len(users) == 0 {
		return nil, nil, fmt.Errorf("user not found or decode error")
	}
	user := users[0]
	// Get groups
	userID := user["id"].(string)
	groupsURL := fmt.Sprintf("%s/admin/realms/%s/users/%s/groups", baseURL, realm, userID)
	greq, _ := http.NewRequest("GET", groupsURL, nil)
	greq.Header.Set("Authorization", "Bearer "+adminToken)
	gresp, err := http.DefaultClient.Do(greq)
	if err != nil {
		return user, nil, err
	}
	defer gresp.Body.Close()
	var groups []map[string]interface{}
	if err := json.NewDecoder(gresp.Body).Decode(&groups); err != nil {
		return user, nil, err
	}
	groupNames := []string{}
	for _, g := range groups {
		if name, ok := g["name"].(string); ok {
			groupNames = append(groupNames, name)
		}
	}
	return user, groupNames, nil
}

// Helper: Get Keycloak user ID by username
func getKeycloakUserID(baseURL, realm, adminToken, username string) (string, error) {
	url := fmt.Sprintf("%s/admin/realms/%s/users?username=%s", baseURL, realm, username)
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Authorization", "Bearer "+adminToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	var users []map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&users); err != nil || len(users) == 0 {
		return "", fmt.Errorf("user not found or decode error")
	}
	return users[0]["id"].(string), nil
}

// Helper: Get Keycloak group ID by group name
func getKeycloakGroupID(baseURL, realm, adminToken, groupName string) (string, error) {
	url := fmt.Sprintf("%s/admin/realms/%s/groups", baseURL, realm)
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Authorization", "Bearer "+adminToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	var groups []map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&groups); err != nil {
		return "", err
	}
	for _, g := range groups {
		if name, ok := g["name"].(string); ok && name == groupName {
			return g["id"].(string), nil
		}
	}
	return "", fmt.Errorf("group not found")
}
