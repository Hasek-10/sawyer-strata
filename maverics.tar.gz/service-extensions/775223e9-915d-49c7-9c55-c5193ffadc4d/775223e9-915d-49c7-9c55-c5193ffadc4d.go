package main

import (
	"context"
	"net/http"
	"encoding/json"
	"github.com/strata-io/service-extension/orchestrator"
)
// Queue represents a string queue
type Queue struct {
	Elements []string `json:"elements"`
}

// Enqueue adds an element to the queue
func (q *Queue) Enqueue(element string) {
	q.Elements = append(q.Elements, element)
}

// Dequeue removes and returns the front element from the queue
func (q *Queue) Dequeue() (string, bool) {
	if len(q.Elements) == 0 {
		return "", true // queue is empty
	}
	element := q.Elements[0]
	q.Elements = q.Elements[1:]
	return element, false // queue is not empty
}

// IsEmpty checks if the queue is empty
func (q *Queue) IsEmpty() bool {
	return len(q.Elements) == 0
}
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	var (
		logger = api.Logger()
	)
	eventCache, err := api.Cache("/caep-events")
	if err != nil {
		logger.Error("se-authenticate", "Unable to retrieve CAEP event cache! Events may not be processed on some or all users")
	}
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}
	logger.Debug("se", "determining if user is authenticated")
	//"okta" could be any IDP defined in the mavs UI, more sophisticated handling will be required for IDP coexistence
	isEntraAuth, err := session.GetString("Entra_Maverics9.authenticated")
	if err != nil {
		logger.Error("se", "unable to retrieve session value", "error", err.Error())
		return false
	}
	if isEntraAuth == "true" {
		userId, err := session.GetString("okta.email") //this value should match the user_id sent by CAEP events to the CAEP event listener SE
		if err != nil {
			logger.Error("Se", "User ID not found, unable to setup CAEP event queue for authenticated user")
		}
		_, err = eventCache.GetBytes(context.Background(), userId)
		if err != nil{
			logger.Info("Se", "Setting up user caep event queue for: "+userId)
			queue := &Queue{}				
    		jsonBytes,_ :=json.Marshal(queue)
			eventCache.SetBytes(context.Background(),userId,jsonBytes)
			logger.Info("Se", "Success - created event queue for user: "+userId)

		}

		return true
	}

	return false
}

func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "authenticating user")

	entraIDP, err := api.IdentityProvider("Entra_Maverics9")
	if err != nil {
		logger.Error(
			"se", "failed to retrieve Entra_Maverics9 IDP",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return
	}
	entraIDP.Login(rw, req)
}
