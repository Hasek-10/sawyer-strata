package main

import (
	"context"
	"bytes"
	"net/http"
	"container/list"
	"encoding/gob"
	"github.com/strata-io/service-extension/orchestrator"
)
type StringQueue struct {
    queue *list.List
}

func (q *StringQueue) Enqueue(str string) {
    q.queue.PushBack(&list.Element{Value: str})
}

func (q *StringQueue) Dequeue() (string, bool) {
    if q.queue.Len() == 0 {
        return "", false
    }
    e := q.queue.Front()
    str := e.Value.(string)
    q.queue.Remove(e)
    return str, true
}
func NewStringQueue() *StringQueue {
	return &StringQueue{queue: list.New()}
}
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	var (
		logger = api.Logger()
	)
	eventCache, err := api.Cache("/caep-events")
	if err != nil {
		logger.Error("se-authenticate", "Unable to retrieve CAEP event cache! Events may not be processed on some or all users")
	}
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}
	logger.Debug("se", "determining if user is authenticated")
	//"okta" could be any IDP defined in the mavs UI, more sophisticated handling will be required for IDP coexistence
	isOktaAuth, err := session.GetString("Entra_Maverics9.authenticated")
	if err != nil {
		logger.Error("se", "unable to retrieve session value", "error", err.Error())
		return false
	}
	if isOktaAuth == "true" {
		userId, err := session.GetString("Entra_Maverics9.preferred_username") //this value should match the user_id sent by CAEP events to the CAEP event listener SE
		if err != nil {
			logger.Error("Se", "User ID not found, unable to setup CAEP event queue for authenticated user")
		}
		_, err = eventCache.GetBytes(context.Background(), userId)
		if err != nil{
			logger.Info("Se", "Setting up user caep event queue for: "+userId)
			q := NewStringQueue()
			var buf bytes.Buffer					
    		enc := gob.NewEncoder(&buf)
			enc.Encode(&q)
			eventCache.SetBytes(context.Background(),userId,buf.Bytes())
			logger.Info("Se", "Success - created event queue for user: "+userId)
		}

		return true
	}

	return false
}

func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "authenticating user")

	entraIDP, err := api.IdentityProvider("Entra_Maverics9")
	if err != nil {
		logger.Error(
			"se", "failed to retrieve Entra_Maverics9 IDP",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return
	}
	entraIDP.Login(rw, req)
}
