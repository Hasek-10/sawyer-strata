package main
import (
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

var (
    client1 = map[string]any {
        "client_id":    "d48ea01e-464e-45f2-9c49-c1be32dfd2e5",
        "sub":          "d48ea01e-464e-45f2-9c49-c1be32dfd2e5",
        "aud":          "https://adfs.stratademo.io/adfs/oauth2/token/"     ,
	}

)

// Note: To use this service extension with a SAML user flow, the signature must include a response writer.
// Ex. func BuildTokenClaims(api orchestrator.Orchestrator, rw, http.ResponseWriter, _ *http.Request) (map[string]any, error)
func BuildAccessTokenClaims(api orchestrator.Orchestrator, req *http.Request) (map[string]any, error) {
	logger := api.Logger()
	clientId := req.FormValue("client_id")

	logger.Debug("function", "BuildAccessTokenClaims", "client_id", clientId)
	var claims map[string]any
	if (clientId == "jpmcTestClient") {
	    claims = client1
	} else if (clientId == "0oajb4l5j50zd3hpV5d7") {
	    claims = client1
	}  else if (clientId == "0oajiv5y0kA2zcwDy5d7") {
	    claims = client1
	}
	return claims, nil
}