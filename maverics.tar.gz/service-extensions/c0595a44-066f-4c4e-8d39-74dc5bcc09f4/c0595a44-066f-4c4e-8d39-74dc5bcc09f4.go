package main

import (
	"bytes"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"

	"github.com/go-jose/go-jose/v3"
	"github.com/go-jose/go-jose/v3/jwt"
	"github.com/strata-io/service-extension/idfabric"
	"github.com/strata-io/service-extension/orchestrator"
)

const (
	pingFedConnName = "PingFed_JPMC_Generic"

	adfsTokenEndpoint    = "https://adfs.stratademo.io/adfs/oauth2/token"
	adfsServerPrivateKey = "adfsServerPrivateKey"

	migratedClientsPath = "migrated-clients.json"
)

// IsLoggedIn is used to direct non-migrated traffic to ADFS and migrated traffic
// to PingFed. False or "not logged in" is returned for migrated traffic. True or
// "logged in" is returned for non-migrated traffic.
func IsLoggedIn(api orchestrator.Orchestrator, _ http.ResponseWriter, req *http.Request) bool {
	var logger = api.Logger()

	if req.Method != http.MethodPost {
		logger.Debug(
			"se", "received non POST request, forwarding to ADFS",
			"method", req.Method,
		)
		return true
	}

	// Reset the request body after reading it to ensure the unmodified body is
	// forwarded to ADFS when necessary.
	var bs bytes.Buffer
	req.Body = io.NopCloser(io.TeeReader(req.Body, &bs))
	defer func() {
		req.Body = io.NopCloser(&bs)
	}()

	err := req.ParseForm()
	if err != nil {
		logger.Error(
			"se", "failed to parse request form",
			"error", err,
		)
		return true
	}

	clientID := req.Form.Get("client_id")
	if len(clientID) == 0 {
		logger.Debug("se", "received request with missing client ID, forwarding request to ADFS")
		return true
	}

	migratedClients, err := fetchMigratedClients()
	if err != nil {
		logger.Error(
			"se", "failed to retrieve migrated clients",
			"error", err.Error(),
		)
		return false
	}
	if _, ok := migratedClients[clientID]; ok {
		logger.Debug(
			"se", "received request for migrated app, starting custom PingFed login",
			"client_id", clientID,
		)
		return false
	}

	logger.Debug(
		"se", "received request for non-migrated app, forwarding to ADFS",
		"client_id", clientID,
	)
	return true
}

// Login handles the authentication against PingFed for migrated applications. This
// is done by validating the original client assertion, crafting a client credentials
// request against PingFed, and returning a re-signed access token.
func Login(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) error {
	logger := api.Logger()

	clientAssertion := req.Form.Get("client_assertion")
	if len(clientAssertion) == 0 {
		logger.Debug("se", "request is missing 'client_assertion'")
		errResp := &oidcErrorResponse{
			Error:            "invalid_client",
			ErrorDescription: "invalid_client",
			code:             http.StatusBadRequest,
		}
		errResp.Write(rw)
		return nil
	}

	err := validateClientAssertion(clientAssertion)
	if err != nil {
		logger.Debug(
			"se", "failed to validate client assertion",
			"error", err,
		)
		errResp := &oidcErrorResponse{
			Error:            "invalid_client",
			ErrorDescription: "invalid_client",
			code:             http.StatusBadRequest,
		}
		errResp.Write(rw)
		return nil
	}
	logger.Debug("se", "successfully validated client assertion for migrated application")

	token, err := handlePingFedClientCredentialsReq(api, rw, req)
	if err != nil {
		logger.Error(
			"se", "failed to make client credentials token request to PingFed",
			"error", err,
		)
		errResp := &oidcErrorResponse{
			Error:            "server_error",
			ErrorDescription: "server_error",
			code:             http.StatusBadRequest,
		}
		errResp.Write(rw)
		return nil
	}
	logger.Debug("se", "received successful response from PingFed client credentials grant request")

	accessToken, err := buildADFSAccessToken(api, token.AccessToken)
	if err != nil {
		errResp := &oidcErrorResponse{
			Error:            "server_error",
			ErrorDescription: "server_error",
			code:             http.StatusBadRequest,
		}
		errResp.Write(rw)
		return nil
	}

	token.AccessToken = accessToken

	bs, err := json.Marshal(token)
	if err != nil {
		logger.Error(
			"se", "failed to marshal access token",
			"error", err,
		)
		errResp := &oidcErrorResponse{
			Error:            "server_error",
			ErrorDescription: "server_error",
			code:             http.StatusBadRequest,
		}
		errResp.Write(rw)
		return nil
	}

	rw.Header().Set("Content-Type", "application/json")
	_, _ = rw.Write(bs)
	return nil
}

func buildADFSAccessToken(api orchestrator.Orchestrator, token string) (string, error) {
	logger := api.Logger()

	at, err := jwt.ParseSigned(token)
	if err != nil {
		logger.Error(
			"se", "error parsing access token",
			"error", err,
		)
		return "", err
	}

	pingFedClaims := map[string]any{}
	err = at.UnsafeClaimsWithoutVerification(&pingFedClaims)
	if err != nil {
		logger.Error(
			"se", "error parsing claims",
			"error", err,
		)
		return "", err
	}

	sp, err := api.SecretProvider()
	if err != nil {
		logger.Error(
			"se", "error retrieving secret provider",
			"error", err,
		)
		return "", err
	}

	orchPrivateKeyStr := sp.GetString(adfsServerPrivateKey)
	block, _ := pem.Decode([]byte(orchPrivateKeyStr))
	if block == nil {
		logger.Error("se", "failed to retrieve ADFS server private key")
		return "", errors.New("failed to retrieve ADFS server private key")
	}

	orchPrivateKey, err := x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil {
		logger.Error(
			"se", "failed to parse ADFS private key",
			"error", err,
		)
		return "", err
	}

	signer, err := jose.NewSigner(
		jose.SigningKey{
			Key:       orchPrivateKey,
			Algorithm: jose.RS256,
		},
		nil,
	)
	if err != nil {
		logger.Error(
			"se", "failed to create signer",
			"error", err,
		)
		return "", err
	}

	adfsAT, err := jwt.Signed(signer).Claims(pingFedClaims).CompactSerialize()
	if err != nil {
		logger.Error(
			"se", "failed to sign access token",
			"error", err,
		)
		return "", err
	}

	return adfsAT, nil
}

func validateClientAssertion(rawClientAssertion string) error {
	clientAssertion, err := jwt.ParseSigned(rawClientAssertion)
	if err != nil {
		return err
	}

	var unverifiedClaims jwt.Claims
	err = clientAssertion.UnsafeClaimsWithoutVerification(&unverifiedClaims)
	if err != nil {
		return err
	}

	if unverifiedClaims.Expiry.Time().Before(time.Now()) ||
		unverifiedClaims.Expiry.Time().After(time.Now().Add(time.Hour)) {
		return errors.New("expired client assertion")
	}

	var audMatchFound bool
	for _, aud := range unverifiedClaims.Audience {
		if aud == adfsTokenEndpoint {
			audMatchFound = true
			break
		}
	}
	if !audMatchFound {
		return errors.New("invalid audience")
	}

	migratedClients, err := fetchMigratedClients()
	if err != nil {
		return fmt.Errorf("failed to retrieve migrated clients: %w", err)
	}

	rawPubKey, ok := migratedClients[unverifiedClaims.Subject]
	if !ok {
		return fmt.Errorf(
			"no public key found for client '%s'",
			unverifiedClaims.Subject,
		)
	}

	block, _ := pem.Decode([]byte(rawPubKey))
	if len(block.Bytes) == 0 {
		return errors.New("failed to PEM decode public key")
	}

	pubKey, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return err
	}

	var verifiedClaims *jwt.Claims
	err = clientAssertion.Claims(pubKey, &verifiedClaims)
	if err != nil {
		return err
	}

	return nil
}

func handlePingFedClientCredentialsReq(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) (*tokenResponse, error) {
	logger := api.Logger()
	logger.Debug("se", "making client credentials request against PingFed")

	loginResult := &idfabric.LoginResult{}

	idp, err := api.IdentityProvider(pingFedConnName)
	if err != nil {
		return nil, fmt.Errorf("failed to retrieve '%s' IDP: %w", pingFedConnName, err)
	}

	idp.Login(rw, req, idfabric.WithGrantTypeClientCredentials(loginResult))
	if loginResult.Error != nil {
		return nil, loginResult.Error
	}

	return &tokenResponse{
		AccessToken: loginResult.AccessToken,
		Scope:       loginResult.Scope,
		ExpiresIn:   loginResult.ExpiresIn,
	}, nil
}

type tokenResponse struct {
	AccessToken  string `json:"access_token,omitempty"`
	TokenType    string `json:"token_type,omitempty"`
	RefreshToken string `json:"refresh_token,omitempty"`
	IDToken      string `json:"id_token,omitempty"`
	Scope        string `json:"scope,omitempty"`
	ExpiresIn    int    `json:"expires_in"`
}

type oidcErrorResponse struct {
	Error            string `json:"error"`
	ErrorDescription string `json:"error_description,omitempty"`
	code             int    `json:"-"`
}

// Write writes the error response body to the ResponseWriter along with the
// appropriate headers.
func (oer *oidcErrorResponse) Write(rw http.ResponseWriter) {
	rw.Header().Set("Content-Type", "application/json")
	rw.Header().Set("Pragma", "no-cache")
	rw.Header().Set("Cache-Control", "no-store")
	rw.WriteHeader(oer.code)
	_, _ = rw.Write(oer.Body())
}

func (oer *oidcErrorResponse) Body() []byte {
	b, _ := json.Marshal(oer)
	return b
}

func fetchMigratedClients() (map[string]string, error) {
	rawClients, err := os.ReadFile(migratedClientsPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read file: %s", err)
	}

	var clients map[string]string
	err = json.Unmarshal(rawClients, &clients)
	if err != nil {
		return nil, fmt.Errorf("failed to unmarshal: %s", err)
	}

	return clients, nil
}