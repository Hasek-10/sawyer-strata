package main

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/idfabric"
	"github.com/strata-io/service-extension/orchestrator"
)

const (
	// Mav UI names of the auth0 IDP. Change as needed
	auth0IDP = "Atlas_DEV_Tenant"

	// Mav UI name of the ldap service. Change as needed
	ldapIDP              = "LDAP_Authentication"
	ldapAttrProviderName = "LDAP_AttrProvider"

	// The value to look for contained within the magic LDAP attribute. Change as needed
	magicValue = "Okta-OIDC-Fastpass-Mav12"

	// The LDAP attribute containing the magic value. Change as needed
	// TO DO: change it to ptcgroups and uncomment the code for checking it
	magicLdapAttributeName = "description"
)

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.
func IsAuthenticated(
	api orchestrator.Orchestrator,
	_ http.ResponseWriter,
	_ *http.Request,
) bool {
	logger := api.Logger()
	logger.Debug("msg", "determining if user is authenticated")

	sess, err := api.Session()
	if err != nil {
		logger.Error(
			"se", "failed to retrieve session",
			"error", err.Error(),
		)
		return false
	}

	auth0Authenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", auth0IDP))
	if auth0Authenticated == "true" {
		logger.Debug("msg", "user is authenticated with Auth0, mapping Auth0 claims")

		//Additional auth0 attributes that need to be placed on the session for the application should be mapped here.
		mapClaim(api, auth0IDP+".email", "generic.SM_USER")
		mapClaim(api, auth0IDP+".email", "generic.email")
		mapClaim(api, auth0IDP+".firstName", "generic.firstname")
		mapClaim(api, auth0IDP+".lastName", "generic.lastname")
		return true
	}

	ldapAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", ldapIDP))
	if ldapAuthenticated == "true" {
		firstName, _ := sess.GetString(ldapIDP + ".firstname")
		lastName, _ := sess.GetString(ldapIDP + ".lastname")
		email, _ := sess.GetString(ldapIDP + ".email")
		logger.Debug(
			"se", "user is authenticated with LDAP, mapping LDAP claims",
			"firstname", firstName,
			"lastname", lastName,
			"email", email,
		)

		//Additional LDAP attributes that need to be placed on the session for the application should be mapped here.
		mapClaim(api, ldapIDP+".email", "generic.SM_USER")
		mapClaim(api, ldapIDP+".email", "generic.email")
		mapClaim(api, ldapIDP+".firstname", "generic.firstname")
		mapClaim(api, ldapIDP+".lastname", "generic.lastname")
		return true
	}

	return false
}

func mapClaim(api orchestrator.Orchestrator, oldClaim, newClaim string) {
	logger := api.Logger()
	sess, err := api.Session()
	if err != nil {
		logger.Error(
			"se", "failed to retrieve session",
			"error", err.Error(),
		)
		return
	}

	claimValue, _ := sess.GetString(oldClaim)
	if claimValue == "" {
		logger.Info(
			"se", "failed to map claim",
			"claim", oldClaim,
		)
		return
	}
	logger.Info(
		"se", "mapping new claim",
		"newClaim", newClaim,
		"oldClaim", oldClaim,
	)

	_ = sess.SetString(newClaim, claimValue)
	err = sess.Save()
	if err != nil {
		logger.Error(
			"se", "failed to save session",
			"error", err.Error(),
		)
	}
}

// Authenticate authenticates the user against the IDP that is selected for
// them based on the LDAP attribute value.
func Authenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	logger.Info("se", "authenticating user")

	sess, err := api.Session()
	if err != nil {
		logger.Error(
			"se", "failed to retrieve session",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return
	}

	username := req.FormValue("username")
	auth0Authenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", auth0IDP))
	ldapAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", ldapIDP))

	if auth0Authenticated != "true" && ldapAuthenticated != "true" && len(username) == 0 {
		logger.Debug("se", "rendering username input form")
		_, _ = rw.Write([]byte(idpForm))

		//assets := api.ServiceExtensionAssets()
		//idpFormFromAsset, err := assets.ReadFile("idpForm.html")
		//if err != nil {
		//	logger.Error("se", "failed to read service extension asset file", "error", err.Error())
		//	http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		//	return
		//}
		//logger.Info("se", "received GET request, rendering IDP selector form")
		//_, _ = rw.Write(idpFormFromAsset)
		return
	}

	if req.Method != http.MethodPost {
		logger.Error(
			"se", "request has unexpected method, expected POST",
			"method", req.Method,
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return
	}

	logger.Info("msg", "parsing form from request")
	err = req.ParseForm()
	if err != nil {
		logger.Error(
			"se", "failed to parse form from request",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return
	}

	ldapAttrProvider, err := api.AttributeProvider(ldapAttrProviderName)
	if err != nil {
		logger.Error(
			"se", "failed to retrieve LDAP attribute provider",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return
	}

	attrs, err := ldapAttrProvider.Query(
		username,
		[]string{magicLdapAttributeName, "mail", "sn", "givenName"},
	)
	if err != nil {
		logger.Error(
			"se", "failed to query LDAP",
			"error", err.Error(),
		)
		//http.Error(
		//	rw,
		//	http.StatusText(http.StatusInternalServerError),
		//	http.StatusInternalServerError,
		//)
		return
	}
	fn := attrs[ldapAttrProviderName+".givenName"]
	sn := attrs[ldapAttrProviderName+".sn"]
	em := attrs[ldapAttrProviderName+".mail"]
	magicAttrValue := attrs[ldapAttrProviderName+"."+magicLdapAttributeName]
	logger.Info(
		"se", "successfully queried LDAP",
		"givenName", fn,
		"sn", sn,
		"mail", em,
	)

	//Look for the magic value in the given ldap attribute - these are constants defined at the top of the file
	idp := auth0IDP
	if !strings.Contains(magicAttrValue, magicValue) {
		idp = ldapIDP

		logger.Debug("LDAP attributes", "Putting the attributes on the session")
		_ = sess.SetString(ldapIDP+".firstname", fn)
		_ = sess.SetString(ldapIDP+".lastname", sn)
		_ = sess.SetString(ldapIDP+".email", em)
		err = sess.Save()
		if err != nil {
			logger.Error(
				"se", "failed to save LDAP attributes to the session",
				"error", err.Error(),
			)
			http.Error(
				rw,
				http.StatusText(http.StatusInternalServerError),
				http.StatusInternalServerError,
			)
			return
		}
	}

	logger.Info(
		"se", "authenticating user",
		"targetIDP", idp,
	)
	provider, err := api.IdentityProvider(idp)
	if err != nil {
		logger.Error(
			"se", "failed to retrieve IDP",
			"error", err.Error(),
		)
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		return
	}

	if idp == auth0IDP {
		loginHintOption := idfabric.WithLoginHint(username)
		provider.Login(rw, req, loginHintOption)
	} else {
		provider.Login(rw, req)
	}
}

// idpForm is a basic form that is rendered in order to enable the user to pick which
// IDP they want to authenticate against. The markup can be styled as necessary,
// loaded from an external file, be rendered as a dynamic template, etc.
const idpForm = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery.js"></script>
    <link rel="shortcut icon" href="https://www.ptc.com/dist/ptc/images/ptc-favicon-16x16-gray.png">
    <title>
        PTC Login
    </title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-image: url(https://ptc-p-001.sitecorecontenthub.cloud/api/public/content/dd5bfb7ef94e4a398b8c47fe85e2c9f6?v=c470941c);
        }
        .box-shadow{
            -webkit-box-shadow: 1px 2px 13px -4px rgba(0,0,0,0.24);
            -moz-box-shadow: 1px 2px 13px -4px rgba(0,0,0,0.24);
            box-shadow: 1px 2px 13px -4px rgba(0,0,0,0.24);
        }
        .login-div{
            background-color: #FFFFFF; 
            height: 540px; 
            width: 400px;
        }
        @media (max-width: 400px) {
            .login-div {
                width: 100%;
            }
        }
        .input{
            border-color: #88888824;
            font-size:16px;
            line-break: normal;
            height: 52px;
            padding: 0 12px;
            letter-spacing: 0.8px;
            width: 100%;
        }
        .button{
            background-color: #00890b;
            font-size: 16px;
            line-break: normal;
            height: 52px;
            padding: 0 12px;
            letter-spacing: 1px;
            width: 100%;
            color: white;
            border: 0;
            border-radius: 4px;
            font-weight: 700;
        }
        .fs-7{
            font-size: 14px;
        }
        .fs-8{
            font-size: 12px;
        }
    </style>
</head>
<script type="text/javascript">
    window.onload = function () {
        const loginHint = sessionStorage.getItem("loginHint");
        const emailField = document.getElementById("username");
        if(loginHint){
            emailField.value = loginHint;  
        }
    };
</script>
<body>
    <div class="container d-flex flex-column text-center justify-content-center align-items-center min-vh-100">
        <div class="p-sm-5 p-4 box-shadow login-div">
            <div class="w-100">
                <header class="pb-5 pt-4">
                    <img src="https://ptc-p-001.sitecorecontenthub.cloud/api/public/content/ff2edff8b42c48c98e20ad26ede84577?v=aabd3d85" alt="Logo" style="height: 85px;">
                </header>
                <h4>Sign In</h4>
                <form method="post" class="w-100">
                    <div class="text-mono w-100">
                        <div id="usernameInputDiv" class="my-4 text-start w-100">
                            <label class="pb-1 fs-6 fw-bold w-100" for="username">Username(Usually your Email Address)*</label>
                            <input type="text" id="username" name="username" class="input" placeholder="Enter your username" required="">
                        </div>
                        <div id="linkCheckButton" class="w-100 mt-4 mb-2">
                            <button type="submit" id="linkCheck" class="button" onclick="setLoginHintForLdap(event)">Continue</button>
                        </div>
                        <div id="createAccountDiv" class="text-start my-0 fs-7">
                            <p>Don't have an account? <a id="createNewAccountLink" style="color: #00890b; text-decoration: underline; font-weight: 600;" href="https://support.ptc.com/appserver/common/account/createAccount.jsp" >Create account</a></p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>
<script>
    function setLoginHintForLdap(event){
        event.preventDefault();
        const email = document.getElementById("username").value;
        console.log("Logging email before setting in session: " + email);
        sessionStorage.setItem("loginHint", email);
        document.querySelector("form").submit();
    }
</script>
</html>

`