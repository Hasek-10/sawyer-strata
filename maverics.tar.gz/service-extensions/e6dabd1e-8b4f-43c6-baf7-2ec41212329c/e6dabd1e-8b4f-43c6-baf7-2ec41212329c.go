package main

import (
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	var (
		logger  = api.Logger()
	)
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return err
	}
	logger.Debug("se", "loading custom attributes from Graph")

	principal, err := session.GetString("Entra_Maverics9.preferred_username")
	if err != nil {
		return fmt.Errorf("failed to find user email required for LDAP query: %w", err)
	}
    if len(principal) > 0 {
         _ = session.SetString("generic.email", principal)
        //TO DO: Better error checking and logging
        keycl,_ := session.GetString("Entra_Maverics9.given_name")
        _ = session.SetString("generic.firstName", keycl)
        keycl,_ = session.GetString("Entra_Maverics9.family_name")
        _ = session.SetString("generic.lastName", keycl)
    }
    if len(principal) == 0 {
        //TO DO: Better error checking and logging
        keycl,_ := session.GetString("Keycloak.email")
        _ = session.SetString("generic.email", keycl)
        keycl,_ = session.GetString("Keycloak.given_name")
        _ = session.SetString("generic.firstName", keycl)
        keycl,_ = session.GetString("Keycloak.family_name")
        _ = session.SetString("generic.lastName", keycl)
    }
   
	graphApi, err := api.AttributeProvider("Entra_Maverics9_Graph")
	if err != nil {
		return fmt.Errorf("failed to find Graph attribute provider")
	}

	attrs, err := graphApi.Query(principal, []string{"memberOf"})
	if err != nil {
		logger.Info("Failed to query graph, looking for groups on session: %w", err)
	    grpVal,_ := session.GetString("Keycloak.groups")
	    _ = session.SetString("generic.groups", grpVal)
	}
	if err == nil {
    	for k, v := range attrs {
    		logger.Debug(
    			"se", "setting Graph attribute on session",
    			"attribute", k,
    			"value", v,
    		)
    		_ = session.SetString("generic.groups", v)
    	}
    }
	err = session.Save()
	if err != nil {
        return fmt.Errorf("unable to save session state: %w", err)
	}
	return nil
}