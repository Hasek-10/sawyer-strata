package main

import (
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	var (
		logger  = api.Logger()
	)
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return err
	}
	logger.Debug("se", "loading custom attributes from LDAP")

	mail, err := session.GetString("Entra_Maverics9.email")
	if err != nil {
		return fmt.Errorf("failed to find user email required for LDAP query: %w", err)
	}

	graphApi, err := api.AttributeProvider("Entra_Maverics9_Graph")
	if err != nil {
		return fmt.Errorf("failed to find LDAP attribute provider")
	}

	attrs, err := graphApi.Query(mail, []string{"memberOf"})
	if err != nil {
		logger.Info("Failed to query graph, looking for groups on session: %w", err)
	    grpVal,_ := session.GetString("Keycloak.groups")
	    _ = session.SetString("generic.groups", grpVal)
	}
	if err == nil {
    	for k, v := range attrs {
    		logger.Debug(
    			"se", "setting LDAP attribute on session",
    			"attribute", k,
    			"value", v,
    		)
    		_ = session.SetString("generic.groups", v)
    	}
    }
	err = session.Save()
	if err != nil {
        return fmt.Errorf("unable to save session state: %w", err)
	}
	return nil
}