package main

import (
	"net/http"
    "encoding/json"
    "context"
	"github.com/strata-io/service-extension/orchestrator"
	"strings"
)
// Queue represents a string queue
type Queue struct {
	Elements []string `json:"elements"`
}

// Enqueue adds an element to the queue
func (q *Queue) Enqueue(element string) {
	q.Elements = append(q.Elements, element)
}

// Dequeue removes and returns the front element from the queue
func (q *Queue) Dequeue() (string, bool) {
	if len(q.Elements) == 0 {
		return "", true // queue is empty
	}
	element := q.Elements[0]
	q.Elements = q.Elements[1:]
	return element, false // queue is not empty
}

// IsEmpty checks if the queue is empty
func (q *Queue) IsEmpty() bool {
	return len(q.Elements) == 0
}
func IsLoggedIn(api orchestrator.Orchestrator, _ http.ResponseWriter, req *http.Request) bool {
	var logger = api.Logger()
	var session,_ = api.Session()
	logger.Debug("se", "determining if user has session with upstream app")
    eventCache,err := api.Cache("/caep-events")
	if(err != nil){
	    logger.Error("loggedInSE","Unable to get /caep-events cache, events will not be processed!")
	}
    cacheKey,err := session.GetString("Entra_Maverics9.preferred_username")
    if(err != nil){
	    logger.Error("loggedInSE","No preferred_username claim found on session! Unable to retrieve user caep event queue from cache")
	}
	qBytes,err := eventCache.GetBytes(context.Background(),cacheKey)
	if(err != nil){
	    logger.Error("loggedInSE","No event queue for user:'"+cacheKey+"' found in cache! Did IsAuthenticated fail?")
	}
	var q Queue
   err = json.Unmarshal(qBytes,&q)
	if err != nil{
		logger.Error("caep-receiver","Unable to decode event queue bytes for subject: "+cacheKey+" event(s) will not be processed!")
	}
	if q.IsEmpty() == true{
	    logger.Info("loggedInSE","No caep events found in the q! Have a nice day :)")
	    return true
	}
    for q.IsEmpty() == false{
        eventName,_ := q.Dequeue()
        logger.Info("IsLoggedInSE","Processing CAEP EVENT - "+eventName)
        if strings.Contains(eventName,"revoke"){
            logger.Info("IsLoggedInSE","Revoking user session: "+cacheKey)
            //DO STUFF - CALL SLO ENDPOINT, REDIRECT TO UNAUTH PAGE, KILL USER SESSION ETC!!!!
            return false
        }
        
    }
	logger.Debug("se", "user is authenticated with upstream app")
	return true
}

func Login(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) error {
	api.Logger().Info("se", "redirecting user to upstream app's login page")
	
	http.Redirect(rw, req, "/login", http.StatusFound)
	return nil
}