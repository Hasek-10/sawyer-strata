package main

import (
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

const (
	oktaBaseDomain = "dev-473810.okta.com"
)

var clientIDsToIDPsForModify = map[string]oidcClientForModify{
	"examplePingID": {
		ClientID:     "examplePingID",
		ClientSecret: "examplePingSecret",
		IDP:          "ping",
	},
	"exampleOktaID": {
		ClientID:     "exampleOktaID",
		ClientSecret: "exampleOktaSecret",
		IDP:          "okta",
	},
	"0oa16v5d2pqBoa2N6358": {
		ClientID:         "", // if doing a passthrough, no need to store creds.
		ClientSecret:     "",
		IDP:              "okta",
		ManuallyMigrated: true,
	},
}

func ModifyRequest(api orchestrator.Orchestrator, req *http.Request) {
	clientID := req.Form.Get("client_id")
	client, ok := clientIDsToIDPsForModify[clientID]
	if !ok {
		api.Logger().Debug(
			"se", "routing request to PingFederate for unknown client",
			"client_id", clientID,
		)
		return
	}

	if client.ManuallyMigrated {
		api.Logger().Debug("se", "client manually migrated, setting the upstream URL to Okta")
		req.URL.Host = oktaBaseDomain
		req.Host = oktaBaseDomain
	}
}

type oidcClientForModify struct {
	ClientID         string
	ClientSecret     string
	IDP              string
	ManuallyMigrated bool
}
