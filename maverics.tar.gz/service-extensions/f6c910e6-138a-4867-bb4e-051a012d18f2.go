package main

import (
	// The crypto libs are needed if configuring TLS
	//"crypto/tls"
	//"crypto/x509"
	"fmt"
	"net/http"
	"strings"

	// LDAP library requires an alias or the orchestrator will fail to parse the SE
	ldap3 "github.com/go-ldap/ldap/v3"
	"github.com/strata-io/service-extension/orchestrator"
)

const (

	// Mav UI names of the auth0 IDP. Change as needed
	auth0IDP = "Okta-OIDC-Fastpass-Mav12"
	// Mav UI name of the ldap service. Change as needed
	ldapIDP = "LDAP_Authentication"

	// Controls the protocol dialled by the service extension. Will be concatenated with the serverName
	// WARNING: "ldaps://" will require additional setup to use custom certs
	ldapProtocol = "ldap://"

	//LDAP Server name - will be concatenated with the protocol. Change as needed.
	serverName = "services-uscentral.skytap.com:8915"

	// Used to create the ldap search query and may be changed as needed.
	baseDN = "dc=sonarsystems,dc=com"

	// Used to create the ldap search query.The %s is a placeholder for the username retrieved from the login form and should not be removed. Be cautious of changing this.
	filterFmt = "(uid=%s)"

	// Used to create the ldap search query and may be changed as needed.
	delimiter = ","

	// Service account info to execute the ldap query. Ensure you use a secret provider for any production deployment. Change as needed */
	serviceAccountUsername = "cn=admin,dc=sonarsystems,dc=com"

	// Service account info to execute the ldap query. Ensure you use a secret provider for any production deployment. Change as needed */
	serviceAccountPassword = "swordfish"

	// serviceAccountUsername = secret.GetString("serviceAccountUsername")
	// serviceAccountPassword = secret.GetString("serviceAccountPassword")

	// The value to look for contained within the magic LDAP attribute. Change as needed
	magicValue = "auth0"

	// The LDAP attribute containing the magic value. Change as needed
	magicLdapAttributeName = "description"
)

// LOGIN FORM HTML IS DEFINED AT THE BOTTOM OF THE FILE

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.

func IsAuthenticated(
	api orchestrator.Orchestrator,
	_ http.ResponseWriter,
	_ *http.Request,
) bool {
	logger := api.Logger()
	sess, _ := api.Session()

	logger.Debug("msg", "determining if user is authenticated")

	auth0Authenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", auth0IDP))
	if auth0Authenticated == "true" {
		logger.Debug("msg", "user is authenticated with Auth0. Mapping claims from Auth0")

		//Additional auth0 attributes that need to be placed on the session for the application should be mapped here.
		mapClaim(api, auth0IDP+".email", "generic.SM_USER")
		mapClaim(api, auth0IDP+".firstName", "generic.firstname")
		mapClaim(api, auth0IDP+".lastName", "generic.lastname")
		return true
	}

	ldapAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", ldapIDP))
	if ldapAuthenticated == "true" {
		logger.Debug("msg", "user is authenticated with LDAP. Mapping claims from LDAP")
		
		//Additional LDAP attributes that need to be placed on the session for the application should be mapped here.
		mapClaim(api, ldapIDP+".email", "generic.SM_USER")
		mapClaim(api, ldapIDP+".firstname", "generic.firstname")
		mapClaim(api, ldapIDP+".lastname", "generic.lastname")
		return true
	}

	return false
}

func mapClaim(api orchestrator.Orchestrator, oldClaim, newClaim string) {
	logger := api.Logger()
	sess, _ := api.Session()
	claimValue, _ := sess.GetString(oldClaim)
	if claimValue == "" {
		logger.Info(fmt.Sprintf("cannot map claim for %s", oldClaim))
		return
	}
	logger.Info(fmt.Sprintf("mapping new claim %s:%s", newClaim, claimValue))
	_ = sess.SetString(newClaim, claimValue)
	sess.Save()
}

// "Authenticate" authenticates the user against the IDP that maverics selects for them based on the LDAP attribute value
func Authenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	sess, _ := api.Session()
	logger.Info("msg", "authenticating user")

	hasIDPBeenPicked := req.FormValue("username")
	if !IsAuthenticated(api, rw, req) && len(hasIDPBeenPicked) == 0 {
		logger.Debug("se", "rendering username input form")
		_, _ = rw.Write([]byte(fmt.Sprintf(idpForm)))
		return
	}

	if req.Method != http.MethodPost {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"receieved unexpected request type '%s', expected POST",
			req.Method,
		))
		return
	}

	logger.Info("msg", "parsing form from request")
	err := req.ParseForm()
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"failed to parse form from request: %s",
			err,
		))

		return
	}

	//Setup LDAP connection
	ldapURL := fmt.Sprintf(ldapProtocol + serverName)
	logger.Info("se", "dialing to ldap over tcp", "url", ldapURL)

	// We are currently using "DialURL" which needs to be changed to DialTLS once we need to configure LDAPS
	conn, err := ldap3.DialURL(ldapURL)

	if err != nil {
		logger.Error("IDP Detection", fmt.Errorf("unable to dial ldap: %w", err))
		return
	}

	defer conn.Close()

	// BEGIN LDAPS / TLS config
	// Gets the LDAP server CA Cert from the secret provider
	// This needs to be slightly tweaked if / when we configure for LDAPS
	//   caCert := secret.GetString("ldapCACert")
	//   certPool, err := x509.SystemCertPool()
	//   if err != nil {
	//   	logger.Error("IDP Detection", fmt.Errorf("unable to get system cert pool: %w", err))
	//   	return
	//   }
	//   ok := certPool.AppendCertsFromPEM([]byte(caCert))
	//   if !ok {
	//   	logger.Error("IDP Detection", fmt.Errorf("unable to append ca cert to pool: %w", err))
	//   	return
	//   }
	//   err = conn.StartTLS(&tls.Config{
	//   	RootCAs:    certPool,
	//   	ServerName: serverName,
	//   })
	//   if err != nil {
	//   	logger.Error("IDP Detection", fmt.Errorf("unable to start tls: %w", err))
	//   	return
	//   }
	// END LDAPS / TLS config

	//serviceAccountUsername and serviceAccountPassword are defined as constants at the top of the file.
	err = conn.Bind(serviceAccountUsername, serviceAccountPassword)

	if err != nil {
		logger.Error("IDP Detection", fmt.Errorf("unable to bind ldap: %w", err))
		return
	}

	// QUERY LDAP HERE BASED ON value from req.Form.Get("username")
	filterUserVal := req.Form.Get("username")
	filter := fmt.Sprintf(filterFmt, filterUserVal)
	logger.Info("IDP Detection", fmt.Sprintf("Filter for LDAP search:'%s'", filter))
	searchReq := ldap3.NewSearchRequest(
		baseDN,
		ldap3.ScopeWholeSubtree, ldap3.NeverDerefAliases, 0, 0, false,
		filter,
		[]string{magicLdapAttributeName, "mail", "sn", "givenName"}, // A list of LDAP attributes to retrieve. Customizing this list will require you to parse each new attribute, set the value on the session, and then map the value as a generic claim in "IsAuthenticated"
		nil,
	)
	searchResult, err := conn.Search(searchReq)
	if err != nil {
		logger.Error("IDP Detection", fmt.Errorf("Failed to search ldap %w", err))
		return
	}
	logger.Info("IDP Detection", fmt.Sprintf("Results Returned: %d", len(searchResult.Entries)))

	// Parse LDAP Response to retrieve the value we are looking for (the response will be a multi-value string, we're just looking for a specific keyword)
	idp := "LDAP_Authentication"
	for _, entry := range searchResult.Entries {
		logger.Info("IDP Detection", fmt.Sprintf("Search Result Entry - Magic Attribute Value: %s", entry.GetAttributeValue(magicLdapAttributeName)))
		logger.Info("IDP Detection", fmt.Sprintf("Search Result Entry: %s", entry.GetAttributeValue("mail")))
		logger.Info("IDP Detection", fmt.Sprintf("Search Result Entry: %s", entry.GetAttributeValue("sn")))
		logger.Info("IDP Detection", fmt.Sprintf("Search Result Entry: %s", entry.GetAttributeValue("givenName")))

		fn := entry.GetAttributeValue("givenName")
		sn := entry.GetAttributeValue("sn")
		em := entry.GetAttributeValue("mail")

		//Look for the magic value in the given ldap attribute - these are constants defined at the top of the file
		if strings.Contains(entry.GetAttributeValue(magicLdapAttributeName), magicValue) {
			idp = auth0IDP
			break
		}
		if idp == ldapIDP {
			logger.Debug("LDAP attributes", "Putting the attributes on the session")
			sess.SetString(ldapIDP+".firstname", fn)
			sess.SetString(ldapIDP+".lastname", sn)
			sess.SetString(ldapIDP+".email", em)
			err = sess.Save()
			if err != nil {
				logger.Error("Failed to save LDAP attributes to the session. Aborting.")
				return
			}

			logger.Debug("se", fmt.Sprintf("The session attribute value for firstname is: %s", fn))
			logger.Debug("se", fmt.Sprintf("The session attribute value for lastname is: %s", sn))
			logger.Debug("se", fmt.Sprintf("The session attribute value for email is: %s", em))
		}
	}
	logger.Info("msg", fmt.Sprintf("authenticating user against '%s", idp))

	provider, err := api.IdentityProvider(idp)
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf("selected IDP '%s' was not found on AuthProvider", idp))
		return
	}
	provider.Login(rw, req)
}

// idpForm is a basic form that is rendered in order to enable the user to pick which
// IDP they want to authenticate against. The markup can be styled as necessary,
// loaded from an external file, be rendered as a dynamic template, etc.
const idpForm = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Username for IDP Routing</title>
    <link rel="stylesheet" href="idpSelector.css"> </head>
<body>
    <div class="container">
        <img src="placeholder-logo.png" alt="Placeholder Logo" class="logo"> 
		<h1>Enter Username for IDP Routing</h1>
        <form method="POST"> 
		<div class="form-group">
                <label for="username">Username:</label>
				<p>This lets us know where to send you for authentication</p>
                <input type="text" id="username" name="username" placeholder="Enter your username" required>
           </div>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
`